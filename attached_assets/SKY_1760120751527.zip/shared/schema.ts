import { sql } from "drizzle-orm";
import { pgTable, text, varchar, timestamp, integer } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const airports = pgTable("airports", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  iataCode: text("iata_code").notNull().unique(),
  icaoCode: text("icao_code"),
  name: text("name").notNull(),
  city: text("city").notNull(),
  country: text("country").notNull(),
  countryCode: text("country_code").notNull(),
  latitude: text("latitude"),
  longitude: text("longitude"),
  timezone: text("timezone"),
  type: text("type").notNull().default("airport"), // airport, heliport, etc.
});

export const quoteRequests = pgTable("quote_requests", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  originAirport: text("origin_airport").notNull(), // IATA code
  destinationAirport: text("destination_airport").notNull(), // IATA code
  departureDate: text("departure_date").notNull(),
  returnDate: text("return_date"),
  flightType: text("flight_type").notNull(), // 'roundtrip' or 'oneway'
  passengers: integer("passengers").notNull(),
  departureTimeRange: text("departure_time_range"), // time preference for departure
  departureFlightClass: text("departure_flight_class"), // 'Main', 'Premium', 'Business' for departure
  returnTimeRange: text("return_time_range"), // time preference for return
  returnFlightClass: text("return_flight_class"), // 'Main', 'Premium', 'Business' for return
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertQuoteRequestSchema = createInsertSchema(quoteRequests).omit({
  id: true,
  createdAt: true,
}).extend({
  name: z.string().min(2, "El nombre debe tener al menos 2 caracteres"),
  email: z.string().email("Email inválido"),
  phone: z.string().optional(),
  originAirport: z.string().min(3, "El aeropuerto de origen es requerido").max(3, "Código IATA inválido"),
  destinationAirport: z.string().min(3, "El aeropuerto de destino es requerido").max(3, "Código IATA inválido"),
  departureDate: z.string().min(1, "La fecha de ida es requerida"),
  returnDate: z.string().optional(),
  flightType: z.enum(["roundtrip", "oneway"]),
  passengers: z.number().min(1, "Debe haber al menos 1 pasajero").max(10, "Máximo 10 pasajeros"),
  departureTimeRange: z.string().optional(),
  departureFlightClass: z.string().optional(),
  returnTimeRange: z.string().optional(),
  returnFlightClass: z.string().optional(),
});

export const insertAirportSchema = createInsertSchema(airports).omit({
  id: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertQuoteRequest = z.infer<typeof insertQuoteRequestSchema>;
export type QuoteRequest = typeof quoteRequests.$inferSelect;
export type InsertAirport = z.infer<typeof insertAirportSchema>;
export type Airport = typeof airports.$inferSelect;
