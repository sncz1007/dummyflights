# Solución para Páginas Terms y Privacy - SPA Routing Fix

## El Problema
Cuando subes tu sitio web a un servidor estático, las páginas `/terms` y `/privacy` devuelven error 404 porque el servidor busca archivos físicos en esas rutas, pero tu aplicación usa routing del lado del cliente (client-side routing).

## La Solución
He creado archivos de configuración para diferentes tipos de servidores. Usa el que corresponda a tu hosting:

---

## 🟢 NETLIFY (Recomendado - Gratis)
**Archivo incluido: `client/public/_redirects`**

✅ **El archivo ya está incluido en tu build**
- Simplemente sube tu carpeta `dist` a Netlify
- Las rutas `/terms` y `/privacy` funcionarán automáticamente

---

## 🔵 VERCEL (Gratis)
**Archivo incluido: `vercel.json`**

✅ **El archivo ya está en la raíz del proyecto**
- Despliega con Vercel CLI o conecta tu repositorio
- Las rutas funcionarán automáticamente

---

## 🟠 HOSTING TRADICIONAL (Apache/cPanel/Hostinger/etc.)
**Archivo incluido: `.htaccess`**

📋 **Pasos:**
1. Haz build de tu proyecto: `npm run build`
2. Sube todo el contenido de la carpeta `dist` a tu servidor
3. Copia el archivo `.htaccess` a la carpeta raíz de tu sitio web (donde está el index.html)

---

## ⚪ NGINX
**Archivo incluido: `nginx.conf.example`**

📋 **Pasos:**
1. Edita tu configuración de Nginx
2. Agrega el bloque `location` del archivo de ejemplo
3. Reinicia Nginx

---

## ✅ Hosting Gratuitos Recomendados

### 1. NETLIFY (Más fácil)
- Arrastra la carpeta `dist` a netlify.com/drop
- ✅ Configuración automática incluida
- ✅ HTTPS automático
- ✅ CDN global

### 2. VERCEL
- Conecta tu repositorio GitHub
- ✅ Configuración automática incluida
- ✅ HTTPS automático
- ✅ CDN global

### 3. Firebase Hosting
```bash
npm install -g firebase-tools
firebase init hosting
# Selecciona 'dist' como public directory
# Configura como SPA: Yes
firebase deploy
```

---

## 🧪 Cómo Probar
Después de subir con la configuración correcta:

1. ✅ Visita: `tudominio.com/terms` - Debe cargar correctamente
2. ✅ Visita: `tudominio.com/privacy` - Debe cargar correctamente  
3. ✅ Recarga (F5) en estas páginas - Debe seguir funcionando

---

## ⚠️ Importante
- **SIEMPRE** usa la carpeta `dist` generada por `npm run build`
- **NUNCA** subas la carpeta `src` o archivos de desarrollo
- El archivo de configuración debe estar en la carpeta raíz del sitio web

¡Con estos archivos tus páginas de términos y privacidad funcionarán perfectamente en cualquier servidor! 🚀