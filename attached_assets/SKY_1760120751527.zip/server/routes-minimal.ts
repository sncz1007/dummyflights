import express from "express";
import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQuoteRequestSchema } from "@shared/schema";
import { db } from "./db";
import { airports } from "@shared/schema";
import { ilike, or, asc, sql } from "drizzle-orm";

export function setupRoutes(app: Express): Server {
  // Airport search endpoint with advanced functionality
  app.get("/api/airports/search", async (req, res) => {
    const { query } = req.query;
    
    if (!query || typeof query !== "string") {
      return res.json([]);
    }
    
    const searchTerm = query.toLowerCase().trim();
    if (searchTerm.length < 1) {
      return res.json([]);
    }

    try {
      const results = await db
        .select()
        .from(airports)
        .where(
          or(
            ilike(airports.iataCode, `${searchTerm}%`),
            ilike(airports.name, `%${searchTerm}%`),
            ilike(airports.city, `%${searchTerm}%`),
            sql`LOWER(${airports.iataCode}) LIKE ${`%${searchTerm}%`}`,
            sql`LOWER(${airports.name}) ~ ${searchTerm.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}`
          )
        )
        .orderBy(
          sql`CASE 
            WHEN LOWER(${airports.iataCode}) = ${searchTerm} THEN 1
            WHEN LOWER(${airports.iataCode}) LIKE ${`${searchTerm}%`} THEN 2
            WHEN LOWER(${airports.name}) LIKE ${`${searchTerm}%`} THEN 3
            WHEN LOWER(${airports.city}) LIKE ${`${searchTerm}%`} THEN 4
            ELSE 5
          END`,
          asc(airports.name)
        )
        .limit(20);

      res.json(results);
    } catch (error) {
      console.error("Airport search error:", error);
      res.status(500).json({ error: "Search failed" });
    }
  });

  // Quote request endpoint - minimal, emails handled by frontend
  app.post("/api/quote-request", async (req, res) => {
    try {
      const validatedData = insertQuoteRequestSchema.parse(req.body);
      const quoteRequest = await storage.createQuoteRequest(validatedData);
      
      // Simple logging - emails handled by frontend EmailJS
      console.log(`📧 Quote saved: ${quoteRequest.name} (${quoteRequest.originAirport} → ${quoteRequest.destinationAirport})`);
      console.log(`🆔 ID: ${quoteRequest.id}`);

      res.json({ 
        message: "Cotización enviada exitosamente",
        quoteId: quoteRequest.id,
        emailSent: true
      });
    } catch (error) {
      console.error("Error creating quote request:", error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // Get all quote requests (for admin)
  app.get("/api/quote-requests", async (req, res) => {
    try {
      const quotes = await storage.getQuoteRequests();
      res.json(quotes);
    } catch (error) {
      console.error("Error fetching quotes:", error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}