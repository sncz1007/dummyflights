import { readFileSync } from 'fs';
import { parse } from 'csv-parse/sync';
import { db } from './db';
import { airports } from '@shared/schema';

interface AirportCSVRow {
  ident: string;
  type: string;
  name: string;
  elevation_ft: string;
  continent: string;
  iso_country: string;
  iso_region: string;
  municipality: string;
  scheduled_service: string;
  gps_code: string;
  iata_code: string;
  local_code: string;
  home_link: string;
  wikipedia_link: string;
  keywords: string;
}

async function seedAirports() {
  try {
    console.log('Reading airport data...');
    const csvData = readFileSync('./airports.csv', 'utf-8');
    const records: AirportCSVRow[] = parse(csvData, { 
      columns: true, 
      skip_empty_lines: true 
    });

    console.log(`Found ${records.length} airport records`);

    // Filter to only airports with IATA codes and scheduled service
    const validAirports = records.filter(row => 
      row.iata_code && 
      row.iata_code.length === 3 && 
      row.type === 'large_airport' || row.type === 'medium_airport'
    );

    console.log(`Filtered to ${validAirports.length} valid airports with IATA codes`);

    // Process in batches to avoid memory issues
    const batchSize = 100;
    let processed = 0;

    for (let i = 0; i < validAirports.length; i += batchSize) {
      const batch = validAirports.slice(i, i + batchSize);
      
      const airportData = batch.map(row => ({
        iataCode: row.iata_code.toUpperCase(),
        icaoCode: row.ident || row.gps_code || null,
        name: row.name,
        city: row.municipality || 'Unknown',
        country: getCountryName(row.iso_country),
        countryCode: row.iso_country,
        latitude: null,
        longitude: null,
        timezone: null,
        type: row.type
      }));

      try {
        await db.insert(airports).values(airportData).onConflictDoNothing();
        processed += batch.length;
        console.log(`Processed ${processed}/${validAirports.length} airports`);
      } catch (error) {
        console.error('Error inserting batch:', error);
      }
    }

    console.log('Airport seeding completed successfully!');
  } catch (error) {
    console.error('Error seeding airports:', error);
  }
}

function getCountryName(countryCode: string): string {
  const countries: Record<string, string> = {
    'US': 'United States',
    'CA': 'Canada',
    'GB': 'United Kingdom',
    'DE': 'Germany',
    'FR': 'France',
    'ES': 'Spain',
    'IT': 'Italy',
    'JP': 'Japan',
    'CN': 'China',
    'AU': 'Australia',
    'BR': 'Brazil',
    'MX': 'Mexico',
    'AR': 'Argentina',
    'CL': 'Chile',
    'CO': 'Colombia',
    'PE': 'Peru',
    'VE': 'Venezuela',
    'EC': 'Ecuador',
    'BO': 'Bolivia',
    'UY': 'Uruguay',
    'PY': 'Paraguay',
    'GY': 'Guyana',
    'SR': 'Suriname',
    'GF': 'French Guiana'
  };
  return countries[countryCode] || countryCode;
}

// Run the seeding function
seedAirports().catch(console.error);