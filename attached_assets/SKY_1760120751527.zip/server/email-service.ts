// Real email service using EmailJS API
export interface EmailData {
  to: string;
  subject: string;
  html?: string;
  text: string;
  from?: string;
}

export async function sendEmail(emailData: EmailData): Promise<boolean> {
  try {
    // Log the email for debugging
    console.log('='.repeat(50));
    console.log('SENDING EMAIL:');
    console.log('='.repeat(50));
    console.log(`To: ${emailData.to}`);
    console.log(`Subject: ${emailData.subject}`);
    console.log(`Content:\n${emailData.text}`);
    console.log('='.repeat(50));
    
    // Use EmailJS API to send real emails
    if (!process.env.EMAILJS_SERVICE_ID || !process.env.EMAILJS_TEMPLATE_ID || !process.env.EMAILJS_PUBLIC_KEY) {
      console.log('❌ EmailJS not configured, logging email for manual processing');
      return false;
    }

    const response = await fetch('https://api.emailjs.com/api/v1.0/email/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        service_id: process.env.EMAILJS_SERVICE_ID,
        template_id: process.env.EMAILJS_TEMPLATE_ID,
        user_id: process.env.EMAILJS_PUBLIC_KEY,
        accessToken: process.env.EMAILJS_PRIVATE_KEY || '',
        template_params: {
          to_email: emailData.to,
          subject: emailData.subject,
          message: emailData.text,
          from_name: 'SkyBudget',
          reply_to: 'skybudgetfly@gmail.com'
        }
      })
    });

    if (response.ok) {
      console.log('✅ Email sent successfully via EmailJS to:', emailData.to);
      return true;
    } else {
      const errorText = await response.text();
      console.log('❌ EmailJS API Error:', response.status, errorText);
      console.log('📧 Email logged for manual processing');
      return false;
    }
    
  } catch (error) {
    console.error('❌ Error in email service:', error);
    console.log('📧 Email logged for manual processing');
    return false; // Email logged but not sent
  }
}