import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertQuoteRequestSchema } from "@shared/schema";
import { sendProductionEmail } from "./production-email";
import { db } from "./db";
import { airports } from "@shared/schema";
import { ilike, or, asc, sql } from "drizzle-orm";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Google Flights-style airport search with intelligent predictions
  app.get("/api/airports/search", async (req, res) => {
    try {
      const { q } = req.query;
      if (!q || typeof q !== 'string' || q.length < 1) {
        return res.json([]);
      }

      const searchTerm = q.toLowerCase().trim();
      
      // Google Flights-style intelligent search strategy
      let allResults: any[] = [];
      
      // 1. Direct city exact matches (highest priority)
      const cityExactQuery = await db
        .select({
          iataCode: airports.iataCode,
          name: airports.name,
          city: airports.city,
          country: airports.country,
          countryCode: airports.countryCode,
          priority: sql<number>`1`.as('priority')
        })
        .from(airports)
        .where(sql`LOWER(TRIM(${airports.city})) = ${searchTerm}`)
        .limit(20);
      
      allResults.push(...cityExactQuery);

      // 2. City starts with search term (very high priority)
      const cityStartsQuery = await db
        .select({
          iataCode: airports.iataCode,
          name: airports.name,
          city: airports.city,
          country: airports.country,
          countryCode: airports.countryCode,
          priority: sql<number>`2`.as('priority')
        })
        .from(airports)
        .where(sql`LOWER(TRIM(${airports.city})) LIKE ${searchTerm + '%'}`)
        .limit(25);
      
      allResults.push(...cityStartsQuery);

      // 3. Alternative city matches (regex-based search for flexibility)
      const cityRegexQuery = await db
        .select({
          iataCode: airports.iataCode,
          name: airports.name,
          city: airports.city,
          country: airports.country,
          countryCode: airports.countryCode,
          priority: sql<number>`3`.as('priority')
        })
        .from(airports)
        .where(sql`${airports.city} ~* ${'^' + searchTerm}`)
        .limit(25);
      
      allResults.push(...cityRegexQuery);

      // 4. City contains search term (for partial matches)
      const cityContainsQuery = await db
        .select({
          iataCode: airports.iataCode,
          name: airports.name,
          city: airports.city,
          country: airports.country,
          countryCode: airports.countryCode,
          priority: sql<number>`4`.as('priority')
        })
        .from(airports)
        .where(sql`LOWER(${airports.city}) LIKE ${'%' + searchTerm + '%'}`)
        .limit(30);
      
      allResults.push(...cityContainsQuery);

      // 5. Airport name contains search term
      const airportNameQuery = await db
        .select({
          iataCode: airports.iataCode,
          name: airports.name,
          city: airports.city,
          country: airports.country,
          countryCode: airports.countryCode,
          priority: sql<number>`5`.as('priority')
        })
        .from(airports)
        .where(sql`LOWER(${airports.name}) LIKE ${'%' + searchTerm + '%'}`)
        .limit(20);
      
      allResults.push(...airportNameQuery);

      // 6. Country name matches (for broader search)
      const countryQuery = await db
        .select({
          iataCode: airports.iataCode,
          name: airports.name,
          city: airports.city,
          country: airports.country,
          countryCode: airports.countryCode,
          priority: sql<number>`6`.as('priority')
        })
        .from(airports)
        .where(sql`LOWER(${airports.country}) LIKE ${'%' + searchTerm + '%'}`)
        .limit(15);
      
      allResults.push(...countryQuery);

      // Remove duplicates and sort intelligently
      const uniqueResults = allResults
        .filter((airport, index, self) => 
          index === self.findIndex(a => a.iataCode === airport.iataCode)
        )
        .sort((a, b) => {
          // Priority-based sorting with intelligent grouping
          if (a.priority !== b.priority) {
            return a.priority - b.priority;
          }
          
          // Group by city for same priority
          const cityA = a.city.split('(')[0].trim().toLowerCase();
          const cityB = b.city.split('(')[0].trim().toLowerCase();
          
          if (cityA !== cityB) {
            return cityA.localeCompare(cityB);
          }
          
          // Within same city, sort by IATA code
          return a.iataCode.localeCompare(b.iataCode);
        })
        .slice(0, 50) // More comprehensive results like Google Flights
        .map(({ priority, ...airport }) => airport);

      res.json(uniqueResults);
    } catch (error) {
      console.error('Error searching airports:', error);
      res.status(500).json({ message: 'Error searching airports' });
    }
  });

  // Email service configuration

  // Submit quote request
  app.post("/api/quote-request", async (req, res) => {
    try {
      const validation = insertQuoteRequestSchema.safeParse(req.body);
      
      if (!validation.success) {
        return res.status(400).json({ 
          message: "Datos inválidos",
          errors: validation.error.errors 
        });
      }

      const quoteRequest = await storage.createQuoteRequest(validation.data);

      // Simple logging - all emails handled by frontend EmailJS

      console.log(`📧 Quote saved: ${quoteRequest.name} (${quoteRequest.originAirport} → ${quoteRequest.destinationAirport})`);
      console.log(`🆔 ID: ${quoteRequest.id}`);

      res.json({ 
        message: "Cotización enviada exitosamente",
        quoteId: quoteRequest.id,
        emailSent: true
      });

    } catch (error) {
      console.error("Error creating quote request:", error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  // Get all quote requests (for admin)
  app.get("/api/quote-requests", async (req, res) => {
    try {
      const quotes = await storage.getQuoteRequests();
      res.json(quotes);
    } catch (error) {
      console.error("Error fetching quotes:", error);
      res.status(500).json({ message: "Error interno del servidor" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
