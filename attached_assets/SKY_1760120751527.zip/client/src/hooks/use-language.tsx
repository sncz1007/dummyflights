import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'en' | 'es';

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

const translations = {
  en: {
    // Header
    'nav.home': 'Home',
    'nav.flights': 'Flights',
    'nav.about': 'About',
    'nav.contact': 'Contact',
    'nav.privacy': 'Privacy',
    'nav.terms': 'Terms',
    
    // Hero Section
    'hero.title': 'Find Cheap Flights with SkyBudget - Save up to 40%',
    'hero.subtitle': 'Get personalized flight quotes and save on your next trip. Free quotes with guaranteed response in a few minutes via email. (Applies to select airlines only)',
    'hero.cta': 'Get Free Quote',
    
    // Quote Form
    'form.title': 'Get Your Flight Quote',
    'form.payment.notice': 'For your peace of mind, you can pay after receiving your booking code!',
    'form.subtitle': 'Fill out this form and we\'ll send you the best flight options, directly to your email in a few minutes, with instructions for booking.',
    'form.name': 'Full Name',
    'form.name.placeholder': 'Enter your full name',
    'form.email': 'Email Address',
    'form.email.placeholder': 'Enter your email',
    'form.phone': 'Phone Number',
    'form.phone.placeholder': 'Enter your phone number',
    'form.origin': 'Departure Airport',
    'form.origin.placeholder': 'Search departure airport...',
    'form.destination': 'Destination Airport',
    'form.destination.placeholder': 'Search destination airport...',
    'form.airport.search': 'City or airport name...',
    'form.departure': 'Departure Date',
    'form.return': 'Return Date (Optional)',
    'form.passengers': 'Number of Passengers',
    'form.passengers.placeholder': 'Select passengers',
    'form.passengers.1': '1 passenger',
    'form.passengers.2': '2 passengers',
    'form.passengers.3': '3 passengers',
    'form.passengers.4': '4 passengers',
    'form.passengers.5': '5 passengers',
    'form.passengers.6': '6+ passengers',
    'form.class': 'Travel Class',
    'form.class.economy': 'Economy',
    'form.class.business': 'Business',
    'form.class.first': 'First Class',
    'form.flighttype': 'Flight Type',
    'form.flighttype.roundtrip': 'Round Trip',
    'form.flighttype.oneway': 'One Way',
    'form.comments': 'Additional Comments',
    'form.comments.placeholder': 'Special requests, preferences, etc.',
    'form.submit': 'Get My Quote',
    'form.submitting': 'Sending Request...',
    'form.success': 'Request Sent Successfully! You\'ll receive a message with your flight quote and price WITH 40% DISCOUNT APPLIED directly to your email as soon as possible.',
    'form.error': 'Error sending request. Please try again.',
    'form.airport.searching': 'Searching airports...',
    'form.airport.notfound': 'No airports found',
    'form.airport.tryagain': 'Try: Miami, New York, Cali, Paris, London...',
    'form.airport.search.placeholder': 'Search your destination city',
    'form.airport.search.example': 'Type any city: Miami, Cali, Paris...',
    'form.airport.multiple': 'airports',
    
    // Features
    'features.title': 'Why Choose SkyBudget?',
    'features.best.title': 'Best Prices',
    'features.best.desc': 'We compare hundreds of airlines to find you the lowest fares',
    'features.support.title': '24/7 Support',
    'features.support.desc': 'Our expert travel agents are here to help you anytime',
    'features.payments': 'All Payment Methods',
    'features.secure.title': 'Secure Booking',
    'features.secure.desc': 'Your personal and payment information is always protected',
    'features.instant.title': 'Instant Quotes',
    'features.instant.desc': 'Get personalized flight quotes in less than 24 hours',
    
    // Destinations
    'destinations.title': 'Popular Destinations',
    'destinations.subtitle': 'Discover amazing places at unbeatable prices',
    'destinations.from': 'From',
    
    // Testimonials
    'testimonials.title': 'What Our Customers Say',
    'testimonials.1.text': 'SkyBudget saved me over $400 on my trip to Europe. Amazing service!',
    'testimonials.1.name': 'Sarah Johnson',
    'testimonials.1.location': 'New York, NY',
    'testimonials.2.text': 'Fast, reliable, and the best prices I could find anywhere.',
    'testimonials.2.name': 'Michael Chen',
    'testimonials.2.location': 'Los Angeles, CA',
    'testimonials.3.text': 'Excellent customer service and they found me a perfect flight.',
    'testimonials.3.name': 'Emily Rodriguez',
    'testimonials.3.location': 'Miami, FL',
    
    // SEO Content
    'seo.title': 'Travel Tips & Flight Deals',
    'seo.tip1.title': 'Best Time to Book Flights',
    'seo.tip1.content': 'Book domestic flights 1-3 months in advance and international flights 2-8 months ahead for the best deals.',
    'seo.tip2.title': 'Flexible Date Search',
    'seo.tip2.content': 'Be flexible with your travel dates to find cheaper flights. Tuesdays and Wednesdays are often the cheapest days to fly.',
    'seo.tip3.title': 'Compare Airlines',
    'seo.tip3.content': 'Don\'t stick to one airline. Compare prices across multiple carriers to find the best deals for your route.',
    
    // Why Choose Us Section
    'whychoose.title': 'Why Choose SkyBudget for Cheap Flights?',
    'whychoose.subtitle': 'We are your trusted travel agency with the best prices on flight tickets',
    'whychoose.bestprices': 'Best Prices',
    'whychoose.bestprices.desc': 'We compare thousands of options to find the best deals',
    'whychoose.secure': 'Secure Transactions',
    'whychoose.secure.desc': 'Your information is protected with SSL encryption',
    'whychoose.support': '24/7 Support',
    'whychoose.support.desc': 'We are here to help you at any time',
    'whychoose.payments': 'Multiple Payments',
    'whychoose.payments.desc': 'We accept cards, transfers and digital payments',

    // SEO Content Section
    'seo.guide.title': 'Cheap Flights - Complete Guide to Save on Travel',
    'seo.guide.subtitle': 'Discover expert tips to find cheap flight tickets and exclusive offers',
    'seo.guide.bestdays': 'Best Days to Buy Cheap Flights',
    'seo.guide.bestdays.desc': 'Tuesdays and Wednesdays usually have the lowest prices. Book 6-8 weeks in advance for international flights and 3-4 weeks for domestic flights.',
    'seo.guide.seasons': 'Cheap Travel Seasons',
    'seo.guide.seasons.desc': 'April-May and September-October offer the best prices. Avoid Christmas, Easter and July-August to find more economical flights.',
    'seo.guide.tips': 'Tips to Find Deals',
    'seo.guide.tips.desc': 'Use incognito mode, compare airlines, consider alternative airports and stay flexible with dates to get the best prices.',
    'seo.guide.lastminute': 'Last Minute Flights',
    'seo.guide.lastminute.desc': 'Although risky, last minute flights can have significant discounts. Ideal for flexible and adventurous travelers.',
    'seo.guide.loyalty': 'Loyalty Programs',
    'seo.guide.loyalty.desc': 'Join airline mile programs, use travel benefit credit cards and accumulate points for free flights.',
    'seo.guide.documentation': 'Documentation and Requirements',
    'seo.guide.documentation.desc': 'Verify valid passport, necessary visas, required vaccines and baggage restrictions before traveling abroad.',
    'seo.guide.destinations': 'Most Searched Destinations for Cheap Flights',
    'seo.guide.flightsto': 'Flights to',

    // Contact Section
    'contact.title': 'Contact Us',
    'contact.subtitle': 'We are here to help you with your next trip',
    'contact.email': 'Email',
    'contact.email.response': 'Response in a few minutes',

    // Footer
    'footer.about': 'About SkyBudget',
    'footer.about.text': 'Your trusted travel partner for finding the best flight deals worldwide.',
    'footer.contact': 'Contact Info',
    'footer.links': 'Quick Links',
    'footer.social': 'Follow Us',
    'footer.rights': 'All rights reserved.',
    
    // Privacy Policy
    'privacy.title': 'Privacy Policy',
    'privacy.intro': 'At SkyBudget, we respect your privacy and are committed to protecting your personal information.',
    'privacy.collection.title': 'Information Collection',
    'privacy.collection.content': 'We collect information you provide when requesting flight quotes, including name, email, phone number, and travel preferences.',
    'privacy.use.title': 'Use of Information',
    'privacy.use.content': 'We use your information to provide flight quotes, process bookings, and communicate with you about your travel requests.',
    'privacy.sharing.title': 'Information Sharing',
    'privacy.sharing.content': 'We do not sell or share your personal information with third parties except as necessary to provide our services.',
    'privacy.security.title': 'Data Security',
    'privacy.security.content': 'We implement appropriate security measures to protect your personal information against unauthorized access and disclosure.',
    'privacy.cookies.title': 'Cookies',
    'privacy.cookies.content': 'We use cookies to improve your browsing experience and analyze website traffic.',
    'privacy.contact.title': 'Contact',
    'privacy.contact.content': 'For questions about this privacy policy, contact us at:',
    
    // Terms of Service
    'terms.title': 'Terms of Service',
    'terms.intro': 'By using SkyBudget services, you agree to these terms and conditions.',
    'terms.services.title': 'Our Services',
    'terms.services.content': 'SkyBudget provides flight search and booking assistance services. We act as an intermediary between customers and airlines.',
    'terms.quotes.title': 'Flight Quotes',
    'terms.quotes.content': 'Flight quotes are estimates and may change based on availability and airline policies. Final prices will be confirmed before booking.',
    'terms.booking.title': 'Booking Process',
    'terms.booking.content': 'All bookings must be confirmed and paid according to airline and our company policies.',
    'terms.cancellation.title': 'Cancellation Policy',
    'terms.cancellation.content': 'Cancellations are subject to airline policies and may incur fees. Please review cancellation terms before booking.',
    'terms.liability.title': 'Limitation of Liability',
    'terms.liability.content': 'SkyBudget is not liable for flight delays, cancellations, or changes made by airlines.',
    'terms.changes.title': 'Terms Changes',
    'terms.changes.content': 'We reserve the right to modify these terms at any time. Changes will be posted on this page.',
    'terms.contact.title': 'Contact',
    'terms.contact.content': 'For questions about these terms, contact us at:',
  },
  es: {
    // Header
    'nav.home': 'Inicio',
    'nav.flights': 'Vuelos',
    'nav.about': 'Nosotros',
    'nav.contact': 'Contacto',
    'nav.privacy': 'Privacidad',
    'nav.terms': 'Términos',
    
    // Hero Section
    'hero.title': 'Vuelos con el 40% de descuento en SkyBudget',
    'hero.subtitle': 'Obtén cotizaciones personalizadas de vuelos y ahorra en tu próximo viaje. Cotizaciones gratuitas con respuesta garantizada en unos pocos minutos por email. (Aplica solo para algunas aerolíneas)',
    'hero.cta': 'Obtener Cotización Gratis',
    
    // Quote Form
    'form.title': 'Obtén tu Cotización de Vuelo',
    'form.payment.notice': '¡Para tu tranquilidad podrás pagar después de recibir tu código de reserva!',
    'form.subtitle': 'Completa este formulario y te enviaremos las mejores opciones de vuelo, directamente a tu correo electrónico en unos pocos minutos, con instrucciones para reservar.',
    'form.name': 'Nombre Completo',
    'form.name.placeholder': 'Ingresa tu nombre completo',
    'form.email': 'Correo Electrónico',
    'form.email.placeholder': 'Ingresa tu correo electrónico',
    'form.phone': 'Número de Teléfono',
    'form.phone.placeholder': 'Ingresa tu número de teléfono',
    'form.origin': 'Aeropuerto de Salida',
    'form.origin.placeholder': 'Buscar aeropuerto de salida...',
    'form.destination': 'Aeropuerto de Destino',
    'form.destination.placeholder': 'Buscar aeropuerto de destino...',
    'form.airport.search': 'Ciudad o nombre del aeropuerto...',
    'form.departure': 'Fecha de Salida',
    'form.return': 'Fecha de Regreso (Opcional)',
    'form.passengers': 'Número de Pasajeros',
    'form.passengers.placeholder': 'Selecciona pasajeros',
    'form.passengers.1': '1 pasajero',
    'form.passengers.2': '2 pasajeros',
    'form.passengers.3': '3 pasajeros',
    'form.passengers.4': '4 pasajeros',
    'form.passengers.5': '5 pasajeros',
    'form.passengers.6': '6+ pasajeros',
    'form.class': 'Clase de Viaje',
    'form.class.economy': 'Económica',
    'form.class.business': 'Ejecutiva',
    'form.class.first': 'Primera Clase',
    'form.flighttype': 'Tipo de Vuelo',
    'form.flighttype.roundtrip': 'Ida y Vuelta',
    'form.flighttype.oneway': 'Solo Ida',
    'form.comments': 'Comentarios Adicionales',
    'form.comments.placeholder': 'Solicitudes especiales, preferencias, etc.',
    'form.submit': 'Obtener Mi Cotización',
    'form.submitting': 'Enviando Solicitud...',
    'form.success': '¡Solicitud Enviada Exitosamente! Recibirás un mensaje con la cotización y precio de tu vuelo CON 40% DE DESCUENTO APLICADO directamente a tu correo lo más pronto posible.',
    'form.error': 'Error al enviar la solicitud. Por favor intenta de nuevo.',
    'form.airport.searching': 'Buscando aeropuertos...',
    'form.airport.notfound': 'No se encontraron aeropuertos',
    'form.airport.tryagain': 'Prueba con: Miami, New York, Cali, París, Londres...',
    'form.airport.search.placeholder': 'Busca tu ciudad de destino',
    'form.airport.search.example': 'Escribe cualquier ciudad: Miami, Cali, París...',
    'form.airport.multiple': 'aeropuertos',
    
    // Features
    'features.title': '¿Por qué elegir SkyBudget?',
    'features.best.title': 'Mejores Precios',
    'features.best.desc': 'Comparamos cientos de aerolíneas para encontrarte las tarifas más bajas',
    'features.support.title': 'Soporte 24/7',
    'features.support.desc': 'Nuestros agentes expertos están aquí para ayudarte en cualquier momento',
    'features.payments': 'Todos los Métodos de Pago',
    'features.secure.title': 'Reserva Segura',
    'features.secure.desc': 'Tu información personal y de pago siempre está protegida',
    'features.instant.title': 'Cotizaciones Instantáneas',
    'features.instant.desc': 'Obtén cotizaciones personalizadas de vuelos en menos de 24 horas',
    
    // Destinations
    'destinations.title': 'Destinos Populares',
    'destinations.subtitle': 'Descubre lugares increíbles a precios inmejorables',
    'destinations.from': 'Desde',
    
    // Testimonials
    'testimonials.title': 'Lo que dicen nuestros clientes',
    'testimonials.1.text': 'SkyBudget me ahorró más de $400 en mi viaje a Europa. ¡Servicio increíble!',
    'testimonials.1.name': 'Sarah Johnson',
    'testimonials.1.location': 'Nueva York, NY',
    'testimonials.2.text': 'Rápido, confiable y los mejores precios que pude encontrar.',
    'testimonials.2.name': 'Michael Chen',
    'testimonials.2.location': 'Los Ángeles, CA',
    'testimonials.3.text': 'Excelente servicio al cliente y me encontraron el vuelo perfecto.',
    'testimonials.3.name': 'Emily Rodriguez',
    'testimonials.3.location': 'Miami, FL',
    
    // SEO Content
    'seo.title': 'Consejos de Viaje y Ofertas de Vuelos',
    'seo.tip1.title': 'Mejor Momento para Reservar Vuelos',
    'seo.tip1.content': 'Reserva vuelos domésticos 1-3 meses antes y vuelos internacionales 2-8 meses antes para las mejores ofertas.',
    'seo.tip2.title': 'Búsqueda de Fechas Flexibles',
    'seo.tip2.content': 'Sé flexible con tus fechas de viaje para encontrar vuelos más baratos. Martes y miércoles suelen ser los días más baratos para volar.',
    'seo.tip3.title': 'Comparar Aerolíneas',
    'seo.tip3.content': 'No te limites a una aerolínea. Compara precios entre múltiples compañías para encontrar las mejores ofertas para tu ruta.',
    
    // Footer
    'footer.about': 'Acerca de SkyBudget',
    'footer.about.text': 'Tu socio de viajes de confianza para encontrar las mejores ofertas de vuelos en todo el mundo.',
    'footer.contact': 'Información de Contacto',
    'footer.links': 'Enlaces Rápidos',
    'footer.social': 'Síguenos',
    'footer.rights': 'Todos los derechos reservados.',
    
    // Privacy Policy
    'privacy.title': 'Política de Privacidad',
    'privacy.intro': 'En SkyBudget, respetamos tu privacidad y nos comprometemos a proteger tu información personal.',
    'privacy.collection.title': 'Recopilación de Información',
    'privacy.collection.content': 'Recopilamos información que proporcionas al solicitar cotizaciones de vuelos, incluyendo nombre, email, teléfono y preferencias de viaje.',
    'privacy.use.title': 'Uso de la Información',
    'privacy.use.content': 'Usamos tu información para proporcionar cotizaciones de vuelos, procesar reservas y comunicarnos contigo sobre tus solicitudes de viaje.',
    'privacy.sharing.title': 'Compartir Información',
    'privacy.sharing.content': 'No vendemos ni compartimos tu información personal con terceros excepto cuando sea necesario para proporcionar nuestros servicios.',
    'privacy.security.title': 'Seguridad de Datos',
    'privacy.security.content': 'Implementamos medidas de seguridad apropiadas para proteger tu información personal contra acceso no autorizado y divulgación.',
    'privacy.cookies.title': 'Cookies',
    'privacy.cookies.content': 'Usamos cookies para mejorar tu experiencia de navegación y analizar el tráfico del sitio web.',
    'privacy.contact.title': 'Contacto',
    'privacy.contact.content': 'Para preguntas sobre esta política de privacidad, contáctanos en:',
    
    // Terms of Service
    'terms.title': 'Términos de Servicio',
    'terms.intro': 'Al usar los servicios de SkyBudget, aceptas estos términos y condiciones.',
    'terms.services.title': 'Nuestros Servicios',
    'terms.services.content': 'SkyBudget proporciona servicios de búsqueda y asistencia en reserva de vuelos. Actuamos como intermediarios entre clientes y aerolíneas.',
    'terms.quotes.title': 'Cotizaciones de Vuelos',
    'terms.quotes.content': 'Las cotizaciones de vuelos son estimaciones y pueden cambiar según disponibilidad y políticas de aerolíneas. Los precios finales serán confirmados antes de la reserva.',
    'terms.booking.title': 'Proceso de Reserva',
    'terms.booking.content': 'Todas las reservas deben ser confirmadas y pagadas según las políticas de aerolíneas y nuestra empresa.',
    'terms.cancellation.title': 'Política de Cancelación',
    'terms.cancellation.content': 'Las cancelaciones están sujetas a políticas de aerolíneas y pueden incurrir en tarifas. Por favor revisa los términos de cancelación antes de reservar.',
    'terms.liability.title': 'Limitación de Responsabilidad',
    'terms.liability.content': 'SkyBudget no es responsable por retrasos, cancelaciones o cambios de vuelos realizados por las aerolíneas.',
    'terms.changes.title': 'Cambios en los Términos',
    'terms.changes.content': 'Nos reservamos el derecho de modificar estos términos en cualquier momento. Los cambios serán publicados en esta página.',
    'terms.contact.title': 'Contacto',
    'terms.contact.content': 'Para preguntas sobre estos términos, contáctanos en:',
    
    // Why Choose Us Section
    'whychoose.title': '¿Por Qué Elegir SkyBudget para Vuelos Baratos?',
    'whychoose.subtitle': 'Somos tu agencia de viajes de confianza con los mejores precios en billetes de avión',
    'whychoose.bestprices': 'Mejores Precios',
    'whychoose.bestprices.desc': 'Comparamos miles de opciones para encontrar las mejores ofertas',
    'whychoose.secure': 'Transacciones Seguras',
    'whychoose.secure.desc': 'Tu información está protegida con encriptación SSL',
    'whychoose.support': 'Soporte 24/7',
    'whychoose.support.desc': 'Estamos aquí para ayudarte en cualquier momento',
    'whychoose.payments': 'Múltiples Pagos',
    'whychoose.payments.desc': 'Aceptamos tarjetas, transferencias y pagos digitales',

    // SEO Content Section
    'seo.guide.title': 'Vuelos Baratos - Guía Completa para Ahorrar en Viajes',
    'seo.guide.subtitle': 'Descubre consejos expertos para encontrar billetes de avión baratos y ofertas exclusivas',
    'seo.guide.bestdays': 'Mejores Días para Comprar Vuelos Baratos',
    'seo.guide.bestdays.desc': 'Los martes y miércoles suelen tener los precios más bajos. Reserva con 6-8 semanas de anticipación para vuelos internacionales y 3-4 semanas para vuelos nacionales.',
    'seo.guide.seasons': 'Temporadas Baratas para Viajar',
    'seo.guide.seasons.desc': 'Abril-mayo y septiembre-octubre ofrecen los mejores precios. Evita Navidad, Semana Santa y julio-agosto para encontrar vuelos más económicos.',
    'seo.guide.tips': 'Consejos para Encontrar Ofertas',
    'seo.guide.tips.desc': 'Usa modo incógnito, compara aerolíneas, considera aeropuertos alternativos y mantente flexible con las fechas para obtener los mejores precios.',
    'seo.guide.lastminute': 'Vuelos de Última Hora',
    'seo.guide.lastminute.desc': 'Aunque arriesgado, los vuelos de última hora pueden tener descuentos significativos. Ideal para viajeros flexibles y aventureros.',
    'seo.guide.loyalty': 'Programas de Lealtad',
    'seo.guide.loyalty.desc': 'Únete a programas de millas de aerolíneas, usa tarjetas de crédito con beneficios de viaje y acumula puntos para vuelos gratuitos.',
    'seo.guide.documentation': 'Documentación y Requisitos',
    'seo.guide.documentation.desc': 'Verifica pasaporte vigente, visas necesarias, vacunas requeridas y restricciones de equipaje antes de viajar al extranjero.',
    'seo.guide.destinations': 'Destinos Más Buscados para Vuelos Baratos',
    'seo.guide.flightsto': 'Vuelos a',

    // Contact Section
    'contact.title': 'Contáctanos',
    'contact.subtitle': 'Estamos aquí para ayudarte con tu próximo viaje',
    'contact.email': 'Email',
    'contact.email.response': 'Respuesta en unos pocos minutos',
  }
};

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>('en'); // Always default to English

  useEffect(() => {
    const saved = localStorage.getItem('skybudget-language');
    // Always prefer English as default, only change if user explicitly selected Spanish
    if (saved === 'es') {
      setLanguage('es');
    } else {
      setLanguage('en'); // Force English as primary language
    }
  }, []);

  const changeLanguage = (lang: Language) => {
    setLanguage(lang);
    localStorage.setItem('skybudget-language', lang);
  };

  const t = (key: string): string => {
    return (translations[language] as any)[key] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage: changeLanguage, t }}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}