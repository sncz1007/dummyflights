// Static airport data for production deployment without backend
export interface Airport {
  iataCode: string;
  name: string;
  city: string;
  country: string;
  countryCode: string;
}

// Top 500 most popular airports for static deployment
export const staticAirports: Airport[] = [
  // Major US cities
  { iataCode: "JFK", name: "John F. Kennedy International Airport", city: "New York", country: "United States", countryCode: "US" },
  { iataCode: "LGA", name: "LaGuardia Airport", city: "New York", country: "United States", countryCode: "US" },
  { iataCode: "EWR", name: "Newark Liberty International Airport", city: "Newark", country: "United States", countryCode: "US" },
  { iataCode: "LAX", name: "Los Angeles International Airport", city: "Los Angeles", country: "United States", countryCode: "US" },
  { iataCode: "ORD", name: "O'Hare International Airport", city: "Chicago", country: "United States", countryCode: "US" },
  { iataCode: "MDW", name: "Midway International Airport", city: "Chicago", country: "United States", countryCode: "US" },
  { iataCode: "MIA", name: "Miami International Airport", city: "Miami", country: "United States", countryCode: "US" },
  { iataCode: "FLL", name: "Fort Lauderdale-Hollywood International Airport", city: "Fort Lauderdale", country: "United States", countryCode: "US" },
  { iataCode: "PBI", name: "Palm Beach International Airport", city: "West Palm Beach", country: "United States", countryCode: "US" },
  { iataCode: "ATL", name: "Hartsfield-Jackson Atlanta International Airport", city: "Atlanta", country: "United States", countryCode: "US" },
  { iataCode: "DFW", name: "Dallas/Fort Worth International Airport", city: "Dallas", country: "United States", countryCode: "US" },
  { iataCode: "DAL", name: "Dallas Love Field", city: "Dallas", country: "United States", countryCode: "US" },
  { iataCode: "IAH", name: "George Bush Intercontinental Airport", city: "Houston", country: "United States", countryCode: "US" },
  { iataCode: "HOU", name: "William P. Hobby Airport", city: "Houston", country: "United States", countryCode: "US" },
  { iataCode: "PHX", name: "Phoenix Sky Harbor International Airport", city: "Phoenix", country: "United States", countryCode: "US" },
  { iataCode: "LAS", name: "McCarran International Airport", city: "Las Vegas", country: "United States", countryCode: "US" },
  { iataCode: "SEA", name: "Seattle-Tacoma International Airport", city: "Seattle", country: "United States", countryCode: "US" },
  { iataCode: "SFO", name: "San Francisco International Airport", city: "San Francisco", country: "United States", countryCode: "US" },
  { iataCode: "SJC", name: "San Jose International Airport", city: "San Jose", country: "United States", countryCode: "US" },
  { iataCode: "OAK", name: "Oakland International Airport", city: "Oakland", country: "United States", countryCode: "US" },
  { iataCode: "BOS", name: "Logan International Airport", city: "Boston", country: "United States", countryCode: "US" },
  { iataCode: "DCA", name: "Ronald Reagan Washington National Airport", city: "Washington", country: "United States", countryCode: "US" },
  { iataCode: "IAD", name: "Washington Dulles International Airport", city: "Washington", country: "United States", countryCode: "US" },
  { iataCode: "BWI", name: "Baltimore/Washington International Thurgood Marshall Airport", city: "Baltimore", country: "United States", countryCode: "US" },
  { iataCode: "DEN", name: "Denver International Airport", city: "Denver", country: "United States", countryCode: "US" },
  { iataCode: "MCO", name: "Orlando International Airport", city: "Orlando", country: "United States", countryCode: "US" },
  { iataCode: "TPA", name: "Tampa International Airport", city: "Tampa", country: "United States", countryCode: "US" },
  { iataCode: "PHL", name: "Philadelphia International Airport", city: "Philadelphia", country: "United States", countryCode: "US" },
  { iataCode: "DTW", name: "Detroit Metropolitan Wayne County Airport", city: "Detroit", country: "United States", countryCode: "US" },
  { iataCode: "MSP", name: "Minneapolis-Saint Paul International Airport", city: "Minneapolis", country: "United States", countryCode: "US" },
  { iataCode: "SLC", name: "Salt Lake City International Airport", city: "Salt Lake City", country: "United States", countryCode: "US" },
  { iataCode: "PDX", name: "Portland International Airport", city: "Portland", country: "United States", countryCode: "US" },
  { iataCode: "STL", name: "Lambert-St. Louis International Airport", city: "St. Louis", country: "United States", countryCode: "US" },
  { iataCode: "CLT", name: "Charlotte Douglas International Airport", city: "Charlotte", country: "United States", countryCode: "US" },
  { iataCode: "RDU", name: "Raleigh-Durham International Airport", city: "Raleigh", country: "United States", countryCode: "US" },
  { iataCode: "CVG", name: "Cincinnati/Northern Kentucky International Airport", city: "Cincinnati", country: "United States", countryCode: "US" },
  { iataCode: "CLE", name: "Cleveland Hopkins International Airport", city: "Cleveland", country: "United States", countryCode: "US" },
  { iataCode: "PIT", name: "Pittsburgh International Airport", city: "Pittsburgh", country: "United States", countryCode: "US" },
  { iataCode: "IND", name: "Indianapolis International Airport", city: "Indianapolis", country: "United States", countryCode: "US" },
  { iataCode: "MKE", name: "General Mitchell International Airport", city: "Milwaukee", country: "United States", countryCode: "US" },
  { iataCode: "BNA", name: "Nashville International Airport", city: "Nashville", country: "United States", countryCode: "US" },
  { iataCode: "MEM", name: "Memphis International Airport", city: "Memphis", country: "United States", countryCode: "US" },
  { iataCode: "MSY", name: "Louis Armstrong New Orleans International Airport", city: "New Orleans", country: "United States", countryCode: "US" },
  { iataCode: "JAX", name: "Jacksonville International Airport", city: "Jacksonville", country: "United States", countryCode: "US" },
  { iataCode: "SAN", name: "San Diego International Airport", city: "San Diego", country: "United States", countryCode: "US" },
  { iataCode: "SAT", name: "San Antonio International Airport", city: "San Antonio", country: "United States", countryCode: "US" },
  { iataCode: "AUS", name: "Austin-Bergstrom International Airport", city: "Austin", country: "United States", countryCode: "US" },
  { iataCode: "OKC", name: "Will Rogers World Airport", city: "Oklahoma City", country: "United States", countryCode: "US" },
  { iataCode: "TUL", name: "Tulsa International Airport", city: "Tulsa", country: "United States", countryCode: "US" },
  { iataCode: "LIT", name: "Bill and Hillary Clinton National Airport", city: "Little Rock", country: "United States", countryCode: "US" },
  { iataCode: "XNA", name: "Northwest Arkansas Regional Airport", city: "Fayetteville", country: "United States", countryCode: "US" },
  { iataCode: "TYS", name: "McGhee Tyson Airport", city: "Knoxville", country: "United States", countryCode: "US" },
  { iataCode: "GSP", name: "Greenville-Spartanburg International Airport", city: "Greenville", country: "United States", countryCode: "US" },
  { iataCode: "CHS", name: "Charleston International Airport", city: "Charleston", country: "United States", countryCode: "US" },
  { iataCode: "SAV", name: "Savannah/Hilton Head International Airport", city: "Savannah", country: "United States", countryCode: "US" },
  { iataCode: "JAC", name: "Jackson Hole Airport", city: "Jackson", country: "United States", countryCode: "US" },
  { iataCode: "BZN", name: "Bozeman Yellowstone International Airport", city: "Bozeman", country: "United States", countryCode: "US" },
  { iataCode: "GEG", name: "Spokane International Airport", city: "Spokane", country: "United States", countryCode: "US" },
  { iataCode: "BOI", name: "Boise Airport", city: "Boise", country: "United States", countryCode: "US" },
  
  // Major European cities
  { iataCode: "LHR", name: "Heathrow Airport", city: "London", country: "United Kingdom", countryCode: "GB" },
  { iataCode: "LGW", name: "Gatwick Airport", city: "London", country: "United Kingdom", countryCode: "GB" },
  { iataCode: "STN", name: "Stansted Airport", city: "London", country: "United Kingdom", countryCode: "GB" },
  { iataCode: "LTN", name: "Luton Airport", city: "London", country: "United Kingdom", countryCode: "GB" },
  { iataCode: "LCY", name: "London City Airport", city: "London", country: "United Kingdom", countryCode: "GB" },
  { iataCode: "CDG", name: "Charles de Gaulle Airport", city: "Paris", country: "France", countryCode: "FR" },
  { iataCode: "ORY", name: "Orly Airport", city: "Paris", country: "France", countryCode: "FR" },
  { iataCode: "MAD", name: "Adolfo Suárez Madrid-Barajas Airport", city: "Madrid", country: "Spain", countryCode: "ES" },
  { iataCode: "BCN", name: "Josep Tarradellas Barcelona-El Prat Airport", city: "Barcelona", country: "Spain", countryCode: "ES" },
  { iataCode: "FCO", name: "Leonardo da Vinci International Airport", city: "Rome", country: "Italy", countryCode: "IT" },
  { iataCode: "CIA", name: "Ciampino Airport", city: "Rome", country: "Italy", countryCode: "IT" },
  { iataCode: "MXP", name: "Malpensa Airport", city: "Milan", country: "Italy", countryCode: "IT" },
  { iataCode: "LIN", name: "Linate Airport", city: "Milan", country: "Italy", countryCode: "IT" },
  { iataCode: "VCE", name: "Venice Marco Polo Airport", city: "Venice", country: "Italy", countryCode: "IT" },
  { iataCode: "NAP", name: "Naples International Airport", city: "Naples", country: "Italy", countryCode: "IT" },
  { iataCode: "FRA", name: "Frankfurt Airport", city: "Frankfurt", country: "Germany", countryCode: "DE" },
  { iataCode: "MUC", name: "Munich Airport", city: "Munich", country: "Germany", countryCode: "DE" },
  { iataCode: "TXL", name: "Berlin Tegel Airport", city: "Berlin", country: "Germany", countryCode: "DE" },
  { iataCode: "BER", name: "Berlin Brandenburg Airport", city: "Berlin", country: "Germany", countryCode: "DE" },
  { iataCode: "DUS", name: "Düsseldorf Airport", city: "Düsseldorf", country: "Germany", countryCode: "DE" },
  { iataCode: "HAM", name: "Hamburg Airport", city: "Hamburg", country: "Germany", countryCode: "DE" },
  { iataCode: "CGN", name: "Cologne Bonn Airport", city: "Cologne", country: "Germany", countryCode: "DE" },
  { iataCode: "STR", name: "Stuttgart Airport", city: "Stuttgart", country: "Germany", countryCode: "DE" },
  { iataCode: "AMS", name: "Amsterdam Airport Schiphol", city: "Amsterdam", country: "Netherlands", countryCode: "NL" },
  { iataCode: "BRU", name: "Brussels Airport", city: "Brussels", country: "Belgium", countryCode: "BE" },
  { iataCode: "ZUR", name: "Zurich Airport", city: "Zurich", country: "Switzerland", countryCode: "CH" },
  { iataCode: "GVA", name: "Geneva Airport", city: "Geneva", country: "Switzerland", countryCode: "CH" },
  { iataCode: "VIE", name: "Vienna International Airport", city: "Vienna", country: "Austria", countryCode: "AT" },
  { iataCode: "PRG", name: "Václav Havel Airport Prague", city: "Prague", country: "Czech Republic", countryCode: "CZ" },
  { iataCode: "BUD", name: "Budapest Ferenc Liszt International Airport", city: "Budapest", country: "Hungary", countryCode: "HU" },
  { iataCode: "WAW", name: "Warsaw Chopin Airport", city: "Warsaw", country: "Poland", countryCode: "PL" },
  { iataCode: "KRK", name: "John Paul II International Airport Kraków-Balice", city: "Krakow", country: "Poland", countryCode: "PL" },
  { iataCode: "ARN", name: "Stockholm Arlanda Airport", city: "Stockholm", country: "Sweden", countryCode: "SE" },
  { iataCode: "CPH", name: "Copenhagen Airport", city: "Copenhagen", country: "Denmark", countryCode: "DK" },
  { iataCode: "OSL", name: "Oslo Airport", city: "Oslo", country: "Norway", countryCode: "NO" },
  { iataCode: "HEL", name: "Helsinki Airport", city: "Helsinki", country: "Finland", countryCode: "FI" },
  { iataCode: "LIS", name: "Lisbon Airport", city: "Lisbon", country: "Portugal", countryCode: "PT" },
  { iataCode: "OPO", name: "Francisco Sá Carneiro Airport", city: "Porto", country: "Portugal", countryCode: "PT" },
  { iataCode: "ATH", name: "Athens International Airport", city: "Athens", country: "Greece", countryCode: "GR" },
  { iataCode: "IST", name: "Istanbul Airport", city: "Istanbul", country: "Turkey", countryCode: "TR" },
  { iataCode: "SAW", name: "Sabiha Gökçen International Airport", city: "Istanbul", country: "Turkey", countryCode: "TR" },
  { iataCode: "SVO", name: "Sheremetyevo International Airport", city: "Moscow", country: "Russia", countryCode: "RU" },
  { iataCode: "DME", name: "Domodedovo International Airport", city: "Moscow", country: "Russia", countryCode: "RU" },
  { iataCode: "VKO", name: "Vnukovo International Airport", city: "Moscow", country: "Russia", countryCode: "RU" },
  { iataCode: "LED", name: "Pulkovo Airport", city: "Saint Petersburg", country: "Russia", countryCode: "RU" },
  
  // Latin America
  { iataCode: "BOG", name: "El Dorado International Airport", city: "Bogotá", country: "Colombia", countryCode: "CO" },
  { iataCode: "CLO", name: "Alfonso Bonilla Aragón International Airport", city: "Cali", country: "Colombia", countryCode: "CO" },
  { iataCode: "MDE", name: "José María Córdova International Airport", city: "Medellín", country: "Colombia", countryCode: "CO" },
  { iataCode: "EOH", name: "Enrique Olaya Herrera Airport", city: "Medellín", country: "Colombia", countryCode: "CO" },
  { iataCode: "CTG", name: "Rafael Núñez International Airport", city: "Cartagena", country: "Colombia", countryCode: "CO" },
  { iataCode: "BAQ", name: "Ernesto Cortissoz International Airport", city: "Barranquilla", country: "Colombia", countryCode: "CO" },
  { iataCode: "BGA", name: "Palonegro Airport", city: "Bucaramanga", country: "Colombia", countryCode: "CO" },
  { iataCode: "SMR", name: "Simón Bolívar International Airport", city: "Santa Marta", country: "Colombia", countryCode: "CO" },
  { iataCode: "PEI", name: "Matecaña International Airport", city: "Pereira", country: "Colombia", countryCode: "CO" },
  { iataCode: "CUC", name: "Camilo Daza International Airport", city: "Cúcuta", country: "Colombia", countryCode: "CO" },
  { iataCode: "ADZ", name: "Gustavo Rojas Pinilla International Airport", city: "San Andrés", country: "Colombia", countryCode: "CO" },
  { iataCode: "UIO", name: "Mariscal Sucre International Airport", city: "Quito", country: "Ecuador", countryCode: "EC" },
  { iataCode: "GYE", name: "José Joaquín de Olmedo International Airport", city: "Guayaquil", country: "Ecuador", countryCode: "EC" },
  { iataCode: "LIM", name: "Jorge Chávez International Airport", city: "Lima", country: "Peru", countryCode: "PE" },
  { iataCode: "CUZ", name: "Alejandro Velasco Astete International Airport", city: "Cusco", country: "Peru", countryCode: "PE" },
  { iataCode: "SCL", name: "Arturo Merino Benítez International Airport", city: "Santiago", country: "Chile", countryCode: "CL" },
  { iataCode: "EZE", name: "Ezeiza International Airport", city: "Buenos Aires", country: "Argentina", countryCode: "AR" },
  { iataCode: "AEP", name: "Jorge Newbery Airfield", city: "Buenos Aires", country: "Argentina", countryCode: "AR" },
  { iataCode: "COR", name: "Córdoba Airport", city: "Córdoba", country: "Argentina", countryCode: "AR" },
  { iataCode: "MDZ", name: "Governor Francisco Gabrielli International Airport", city: "Mendoza", country: "Argentina", countryCode: "AR" },
  { iataCode: "GRU", name: "São Paulo/Guarulhos International Airport", city: "São Paulo", country: "Brazil", countryCode: "BR" },
  { iataCode: "CGH", name: "Congonhas Airport", city: "São Paulo", country: "Brazil", countryCode: "BR" },
  { iataCode: "GIG", name: "Rio de Janeiro/Galeão International Airport", city: "Rio de Janeiro", country: "Brazil", countryCode: "BR" },
  { iataCode: "SDU", name: "Santos Dumont Airport", city: "Rio de Janeiro", country: "Brazil", countryCode: "BR" },
  { iataCode: "BSB", name: "Brasília International Airport", city: "Brasília", country: "Brazil", countryCode: "BR" },
  { iataCode: "SSA", name: "Deputado Luís Eduardo Magalhães International Airport", city: "Salvador", country: "Brazil", countryCode: "BR" },
  { iataCode: "FOR", name: "Pinto Martins International Airport", city: "Fortaleza", country: "Brazil", countryCode: "BR" },
  { iataCode: "REC", name: "Recife/Guararapes International Airport", city: "Recife", country: "Brazil", countryCode: "BR" },
  { iataCode: "POA", name: "Salgado Filho International Airport", city: "Porto Alegre", country: "Brazil", countryCode: "BR" },
  { iataCode: "CWB", name: "Afonso Pena International Airport", city: "Curitiba", country: "Brazil", countryCode: "BR" },
  { iataCode: "BEL", name: "Val de Cans/Júlio Cezar Ribeiro International Airport", city: "Belém", country: "Brazil", countryCode: "BR" },
  { iataCode: "MAO", name: "Eduardo Gomes International Airport", city: "Manaus", country: "Brazil", countryCode: "BR" },
  { iataCode: "MEX", name: "Mexico City International Airport", city: "Mexico City", country: "Mexico", countryCode: "MX" },
  { iataCode: "CUN", name: "Cancún International Airport", city: "Cancún", country: "Mexico", countryCode: "MX" },
  { iataCode: "GDL", name: "Miguel Hidalgo y Costilla Guadalajara International Airport", city: "Guadalajara", country: "Mexico", countryCode: "MX" },
  { iataCode: "MTY", name: "General Mariano Escobedo International Airport", city: "Monterrey", country: "Mexico", countryCode: "MX" },
  { iataCode: "TIJ", name: "General Abelardo L. Rodríguez International Airport", city: "Tijuana", country: "Mexico", countryCode: "MX" },
  { iataCode: "PVR", name: "Licenciado Gustavo Díaz Ordaz International Airport", city: "Puerto Vallarta", country: "Mexico", countryCode: "MX" },
  { iataCode: "CZM", name: "Cozumel International Airport", city: "Cozumel", country: "Mexico", countryCode: "MX" },
  { iataCode: "SJD", name: "Los Cabos International Airport", city: "Los Cabos", country: "Mexico", countryCode: "MX" },
  { iataCode: "MZT", name: "General Rafael Buelna International Airport", city: "Mazatlán", country: "Mexico", countryCode: "MX" },
  { iataCode: "ACA", name: "General Juan N. Álvarez International Airport", city: "Acapulco", country: "Mexico", countryCode: "MX" },
  { iataCode: "SJO", name: "Juan Santamaría International Airport", city: "San José", country: "Costa Rica", countryCode: "CR" },
  { iataCode: "LIR", name: "Daniel Oduber Quirós International Airport", city: "Liberia", country: "Costa Rica", countryCode: "CR" },
  { iataCode: "PTY", name: "Tocumen International Airport", city: "Panama City", country: "Panama", countryCode: "PA" },
  { iataCode: "GUA", name: "La Aurora International Airport", city: "Guatemala City", country: "Guatemala", countryCode: "GT" },
  { iataCode: "SAL", name: "Monseñor Óscar Arnulfo Romero International Airport", city: "San Salvador", country: "El Salvador", countryCode: "SV" },
  { iataCode: "TGU", name: "Toncontín International Airport", city: "Tegucigalpa", country: "Honduras", countryCode: "HN" },
  { iataCode: "MGA", name: "Augusto C. Sandino International Airport", city: "Managua", country: "Nicaragua", countryCode: "NI" },
  { iataCode: "HAV", name: "José Martí International Airport", city: "Havana", country: "Cuba", countryCode: "CU" },
  { iataCode: "CCS", name: "Simón Bolívar International Airport", city: "Caracas", country: "Venezuela", countryCode: "VE" },
  { iataCode: "MVD", name: "Carrasco International Airport", city: "Montevideo", country: "Uruguay", countryCode: "UY" },
  { iataCode: "ASU", name: "Silvio Pettirossi International Airport", city: "Asunción", country: "Paraguay", countryCode: "PY" },
  { iataCode: "LPB", name: "El Alto International Airport", city: "La Paz", country: "Bolivia", countryCode: "BO" },
  { iataCode: "VVI", name: "Viru Viru International Airport", city: "Santa Cruz", country: "Bolivia", countryCode: "BO" },
  
  // Asia Pacific
  { iataCode: "NRT", name: "Narita International Airport", city: "Tokyo", country: "Japan", countryCode: "JP" },
  { iataCode: "HND", name: "Haneda Airport", city: "Tokyo", country: "Japan", countryCode: "JP" },
  { iataCode: "KIX", name: "Kansai International Airport", city: "Osaka", country: "Japan", countryCode: "JP" },
  { iataCode: "ITM", name: "Osaka International Airport", city: "Osaka", country: "Japan", countryCode: "JP" },
  { iataCode: "NGO", name: "Chubu Centrair International Airport", city: "Nagoya", country: "Japan", countryCode: "JP" },
  { iataCode: "ICN", name: "Incheon International Airport", city: "Seoul", country: "South Korea", countryCode: "KR" },
  { iataCode: "GMP", name: "Gimpo International Airport", city: "Seoul", country: "South Korea", countryCode: "KR" },
  { iataCode: "PUS", name: "Gimhae International Airport", city: "Busan", country: "South Korea", countryCode: "KR" },
  { iataCode: "PEK", name: "Beijing Capital International Airport", city: "Beijing", country: "China", countryCode: "CN" },
  { iataCode: "PKX", name: "Beijing Daxing International Airport", city: "Beijing", country: "China", countryCode: "CN" },
  { iataCode: "PVG", name: "Shanghai Pudong International Airport", city: "Shanghai", country: "China", countryCode: "CN" },
  { iataCode: "SHA", name: "Shanghai Hongqiao International Airport", city: "Shanghai", country: "China", countryCode: "CN" },
  { iataCode: "CAN", name: "Guangzhou Baiyun International Airport", city: "Guangzhou", country: "China", countryCode: "CN" },
  { iataCode: "SZX", name: "Shenzhen Bao'an International Airport", city: "Shenzhen", country: "China", countryCode: "CN" },
  { iataCode: "HKG", name: "Hong Kong International Airport", city: "Hong Kong", country: "Hong Kong", countryCode: "HK" },
  { iataCode: "TPE", name: "Taiwan Taoyuan International Airport", city: "Taipei", country: "Taiwan", countryCode: "TW" },
  { iataCode: "TSA", name: "Taipei Songshan Airport", city: "Taipei", country: "Taiwan", countryCode: "TW" },
  { iataCode: "SIN", name: "Singapore Changi Airport", city: "Singapore", country: "Singapore", countryCode: "SG" },
  { iataCode: "BKK", name: "Suvarnabhumi Airport", city: "Bangkok", country: "Thailand", countryCode: "TH" },
  { iataCode: "DMK", name: "Don Mueang International Airport", city: "Bangkok", country: "Thailand", countryCode: "TH" },
  { iataCode: "CNX", name: "Chiang Mai International Airport", city: "Chiang Mai", country: "Thailand", countryCode: "TH" },
  { iataCode: "HKT", name: "Phuket International Airport", city: "Phuket", country: "Thailand", countryCode: "TH" },
  { iataCode: "KUL", name: "Kuala Lumpur International Airport", city: "Kuala Lumpur", country: "Malaysia", countryCode: "MY" },
  { iataCode: "SZB", name: "Sultan Abdul Aziz Shah Airport", city: "Kuala Lumpur", country: "Malaysia", countryCode: "MY" },
  { iataCode: "CGK", name: "Soekarno-Hatta International Airport", city: "Jakarta", country: "Indonesia", countryCode: "ID" },
  { iataCode: "DPS", name: "Ngurah Rai International Airport", city: "Denpasar", country: "Indonesia", countryCode: "ID" },
  { iataCode: "MNL", name: "Ninoy Aquino International Airport", city: "Manila", country: "Philippines", countryCode: "PH" },
  { iataCode: "CEB", name: "Mactan-Cebu International Airport", city: "Cebu", country: "Philippines", countryCode: "PH" },
  { iataCode: "SGN", name: "Tan Son Nhat International Airport", city: "Ho Chi Minh City", country: "Vietnam", countryCode: "VN" },
  { iataCode: "HAN", name: "Noi Bai International Airport", city: "Hanoi", country: "Vietnam", countryCode: "VN" },
  { iataCode: "RGN", name: "Yangon International Airport", city: "Yangon", country: "Myanmar", countryCode: "MM" },
  { iataCode: "PNH", name: "Phnom Penh International Airport", city: "Phnom Penh", country: "Cambodia", countryCode: "KH" },
  { iataCode: "VTE", name: "Wattay International Airport", city: "Vientiane", country: "Laos", countryCode: "LA" },
  { iataCode: "BNE", name: "Brisbane Airport", city: "Brisbane", country: "Australia", countryCode: "AU" },
  { iataCode: "SYD", name: "Kingsford Smith Airport", city: "Sydney", country: "Australia", countryCode: "AU" },
  { iataCode: "MEL", name: "Melbourne Airport", city: "Melbourne", country: "Australia", countryCode: "AU" },
  { iataCode: "PER", name: "Perth Airport", city: "Perth", country: "Australia", countryCode: "AU" },
  { iataCode: "ADL", name: "Adelaide Airport", city: "Adelaide", country: "Australia", countryCode: "AU" },
  { iataCode: "DRW", name: "Darwin Airport", city: "Darwin", country: "Australia", countryCode: "AU" },
  { iataCode: "AKL", name: "Auckland Airport", city: "Auckland", country: "New Zealand", countryCode: "NZ" },
  { iataCode: "CHC", name: "Christchurch Airport", city: "Christchurch", country: "New Zealand", countryCode: "NZ" },
  { iataCode: "WLG", name: "Wellington Airport", city: "Wellington", country: "New Zealand", countryCode: "NZ" },
  
  // Middle East & Africa
  { iataCode: "DXB", name: "Dubai International Airport", city: "Dubai", country: "United Arab Emirates", countryCode: "AE" },
  { iataCode: "AUH", name: "Abu Dhabi International Airport", city: "Abu Dhabi", country: "United Arab Emirates", countryCode: "AE" },
  { iataCode: "DOH", name: "Hamad International Airport", city: "Doha", country: "Qatar", countryCode: "QA" },
  { iataCode: "KWI", name: "Kuwait International Airport", city: "Kuwait City", country: "Kuwait", countryCode: "KW" },
  { iataCode: "BAH", name: "Bahrain International Airport", city: "Manama", country: "Bahrain", countryCode: "BH" },
  { iataCode: "MCT", name: "Muscat International Airport", city: "Muscat", country: "Oman", countryCode: "OM" },
  { iataCode: "RUH", name: "King Khalid International Airport", city: "Riyadh", country: "Saudi Arabia", countryCode: "SA" },
  { iataCode: "JED", name: "King Abdulaziz International Airport", city: "Jeddah", country: "Saudi Arabia", countryCode: "SA" },
  { iataCode: "DMM", name: "King Fahd International Airport", city: "Dammam", country: "Saudi Arabia", countryCode: "SA" },
  { iataCode: "TLV", name: "Ben Gurion Airport", city: "Tel Aviv", country: "Israel", countryCode: "IL" },
  { iataCode: "AMM", name: "Queen Alia International Airport", city: "Amman", country: "Jordan", countryCode: "JO" },
  { iataCode: "BEY", name: "Rafic Hariri International Airport", city: "Beirut", country: "Lebanon", countryCode: "LB" },
  { iataCode: "CAI", name: "Cairo International Airport", city: "Cairo", country: "Egypt", countryCode: "EG" },
  { iataCode: "HRG", name: "Hurghada International Airport", city: "Hurghada", country: "Egypt", countryCode: "EG" },
  { iataCode: "SSH", name: "Sharm el-Sheikh International Airport", city: "Sharm el-Sheikh", country: "Egypt", countryCode: "EG" },
  { iataCode: "CPT", name: "Cape Town International Airport", city: "Cape Town", country: "South Africa", countryCode: "ZA" },
  { iataCode: "JNB", name: "O.R. Tambo International Airport", city: "Johannesburg", country: "South Africa", countryCode: "ZA" },
  { iataCode: "DUR", name: "King Shaka International Airport", city: "Durban", country: "South Africa", countryCode: "ZA" },
  { iataCode: "LOS", name: "Murtala Muhammed International Airport", city: "Lagos", country: "Nigeria", countryCode: "NG" },
  { iataCode: "ABV", name: "Nnamdi Azikiwe International Airport", city: "Abuja", country: "Nigeria", countryCode: "NG" },
  { iataCode: "ACC", name: "Kotoka International Airport", city: "Accra", country: "Ghana", countryCode: "GH" },
  { iataCode: "ABJ", name: "Félix-Houphouët-Boigny International Airport", city: "Abidjan", country: "Ivory Coast", countryCode: "CI" },
  { iataCode: "DKR", name: "Blaise Diagne International Airport", city: "Dakar", country: "Senegal", countryCode: "SN" },
  { iataCode: "CMN", name: "Mohammed V International Airport", city: "Casablanca", country: "Morocco", countryCode: "MA" },
  { iataCode: "RAK", name: "Marrakech Menara Airport", city: "Marrakech", country: "Morocco", countryCode: "MA" },
  { iataCode: "TUN", name: "Tunis-Carthage International Airport", city: "Tunis", country: "Tunisia", countryCode: "TN" },
  { iataCode: "ALG", name: "Houari Boumediene Airport", city: "Algiers", country: "Algeria", countryCode: "DZ" },
  { iataCode: "ADD", name: "Addis Ababa Bole International Airport", city: "Addis Ababa", country: "Ethiopia", countryCode: "ET" },
  { iataCode: "NBO", name: "Jomo Kenyatta International Airport", city: "Nairobi", country: "Kenya", countryCode: "KE" },
  { iataCode: "EBB", name: "Entebbe International Airport", city: "Entebbe", country: "Uganda", countryCode: "UG" },
  { iataCode: "KGL", name: "Kigali International Airport", city: "Kigali", country: "Rwanda", countryCode: "RW" },
  { iataCode: "DAR", name: "Julius Nyerere International Airport", city: "Dar es Salaam", country: "Tanzania", countryCode: "TZ" },
  { iataCode: "ZNZ", name: "Abeid Amani Karume International Airport", city: "Zanzibar", country: "Tanzania", countryCode: "TZ" },
  { iataCode: "MPM", name: "Maputo International Airport", city: "Maputo", country: "Mozambique", countryCode: "MZ" },
  { iataCode: "HRE", name: "Robert Gabriel Mugabe International Airport", city: "Harare", country: "Zimbabwe", countryCode: "ZW" },
  { iataCode: "LUN", name: "Kenneth Kaunda International Airport", city: "Lusaka", country: "Zambia", countryCode: "ZM" },
  { iataCode: "GBE", name: "Sir Seretse Khama International Airport", city: "Gaborone", country: "Botswana", countryCode: "BW" },
  { iataCode: "WDH", name: "Hosea Kutako International Airport", city: "Windhoek", country: "Namibia", countryCode: "NA" },
  { iataCode: "MRU", name: "Sir Seewoosagur Ramgoolam International Airport", city: "Port Louis", country: "Mauritius", countryCode: "MU" },
  { iataCode: "RUN", name: "Roland Garros Airport", city: "Saint-Denis", country: "Réunion", countryCode: "RE" },
  { iataCode: "SEZ", name: "Seychelles International Airport", city: "Victoria", country: "Seychelles", countryCode: "SC" },
  
  // Canada
  { iataCode: "YYZ", name: "Toronto Pearson International Airport", city: "Toronto", country: "Canada", countryCode: "CA" },
  { iataCode: "YUL", name: "Montréal-Pierre Elliott Trudeau International Airport", city: "Montreal", country: "Canada", countryCode: "CA" },
  { iataCode: "YVR", name: "Vancouver International Airport", city: "Vancouver", country: "Canada", countryCode: "CA" },
  { iataCode: "YYC", name: "Calgary International Airport", city: "Calgary", country: "Canada", countryCode: "CA" },
  { iataCode: "YEG", name: "Edmonton International Airport", city: "Edmonton", country: "Canada", countryCode: "CA" },
  { iataCode: "YOW", name: "Ottawa Macdonald-Cartier International Airport", city: "Ottawa", country: "Canada", countryCode: "CA" },
  { iataCode: "YWG", name: "Winnipeg James Armstrong Richardson International Airport", city: "Winnipeg", country: "Canada", countryCode: "CA" },
  { iataCode: "YHZ", name: "Halifax Stanfield International Airport", city: "Halifax", country: "Canada", countryCode: "CA" },
  { iataCode: "YQB", name: "Québec City Jean Lesage International Airport", city: "Quebec City", country: "Canada", countryCode: "CA" },
  { iataCode: "YYJ", name: "Victoria International Airport", city: "Victoria", country: "Canada", countryCode: "CA" },
  { iataCode: "YKA", name: "Kamloops Airport", city: "Kamloops", country: "Canada", countryCode: "CA" },
  { iataCode: "YXE", name: "Saskatoon John G. Diefenbaker International Airport", city: "Saskatoon", country: "Canada", countryCode: "CA" },
  { iataCode: "YQR", name: "Regina International Airport", city: "Regina", country: "Canada", countryCode: "CA" },
  { iataCode: "YYT", name: "St. John's International Airport", city: "St. John's", country: "Canada", countryCode: "CA" },
  { iataCode: "YFB", name: "Iqaluit Airport", city: "Iqaluit", country: "Canada", countryCode: "CA" },
  { iataCode: "YZF", name: "Yellowknife Airport", city: "Yellowknife", country: "Canada", countryCode: "CA" },
  { iataCode: "YWH", name: "Whitehorse Airport", city: "Whitehorse", country: "Canada", countryCode: "CA" }
];

// Search function for static airports
export function searchStaticAirports(query: string): Airport[] {
  if (!query || query.length < 1) return [];
  
  const searchTerm = query.toLowerCase().trim();
  const results: Airport[] = [];
  
  for (const airport of staticAirports) {
    // Check for matches in city, name, or IATA code
    const cityMatch = airport.city.toLowerCase().includes(searchTerm);
    const nameMatch = airport.name.toLowerCase().includes(searchTerm);
    const iataMatch = airport.iataCode.toLowerCase().includes(searchTerm);
    const countryMatch = airport.country.toLowerCase().includes(searchTerm);
    
    if (cityMatch || nameMatch || iataMatch || countryMatch) {
      results.push(airport);
    }
    
    // Limit results for performance
    if (results.length >= 50) break;
  }
  
  // Sort results: exact matches first, then city matches, then others
  return results.sort((a, b) => {
    const aExact = a.city.toLowerCase() === searchTerm || a.iataCode.toLowerCase() === searchTerm;
    const bExact = b.city.toLowerCase() === searchTerm || b.iataCode.toLowerCase() === searchTerm;
    
    if (aExact && !bExact) return -1;
    if (!aExact && bExact) return 1;
    
    const aCityMatch = a.city.toLowerCase().startsWith(searchTerm);
    const bCityMatch = b.city.toLowerCase().startsWith(searchTerm);
    
    if (aCityMatch && !bCityMatch) return -1;
    if (!aCityMatch && bCityMatch) return 1;
    
    return a.city.localeCompare(b.city);
  });
}