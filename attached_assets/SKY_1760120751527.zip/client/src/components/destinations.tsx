import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";

const destinations = [
  {
    name: "Cusco, Perú",
    price: "40% Off",
    image: "https://images.unsplash.com/photo-1587595431973-160d0d94add1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
    alt: "Machu Picchu, Perú"
  },
  {
    name: "Rio de Janeiro",
    price: "40% Off",
    image: "https://images.unsplash.com/photo-1483729558449-99ef09a8c325?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
    alt: "Rio de Janeiro, Brasil"
  },
  {
    name: "Barcelona",
    price: "40% Off",
    image: "https://images.unsplash.com/photo-1539037116277-4db20889f2d4?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
    alt: "Barcelona, España"
  },
  {
    name: "Tokyo",
    price: "40% Off",
    image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
    alt: "Tokyo, Japón"
  },
  {
    name: "Santorini",
    price: "40% Off",
    image: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
    alt: "Santorini, Grecia"
  },
  {
    name: "New York",
    price: "40% Off",
    image: "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
    alt: "New York, EE.UU."
  },
  {
    name: "Dubai",
    price: "40% Off",
    image: "https://images.unsplash.com/photo-1512453979798-5ea266f8880c?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
    alt: "Dubai, EAU"
  },
  {
    name: "Bali",
    price: "40% Off",
    image: "https://images.unsplash.com/photo-1537953773345-d172ccf13cf1?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=400&h=300",
    alt: "Bali, Indonesia"
  }
];

export default function Destinations() {
  const { t } = useLanguage();
  
  return (
    <section id="destinos" className="py-16 bg-white" data-testid="destinations-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-sky-dark mb-4" data-testid="destinations-title">
            {t('destinations.title')}
          </h2>
          <p className="text-lg text-gray-600" data-testid="destinations-subtitle">
            {t('destinations.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
          {destinations.map((destination, index) => (
            <Card 
              key={destination.name} 
              className="overflow-hidden hover:shadow-xl transition-shadow duration-300"
              data-testid={`destination-card-${index}`}
            >
              <div className="relative">
                <img 
                  src={destination.image} 
                  alt={destination.alt}
                  className="w-full h-48 object-cover"
                  data-testid={`destination-image-${index}`}
                />
              </div>
              <CardContent className="p-4">
                <h4 className="font-semibold text-lg text-gray-900 mb-1" data-testid={`destination-name-${index}`}>
                  {destination.name}
                </h4>
                <p className="text-gray-600 text-sm mb-2">{t('destinations.from')}</p>
                <p className="text-2xl font-bold text-sky-red" data-testid={`destination-price-${index}`}>
                  {destination.price}
                </p>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
