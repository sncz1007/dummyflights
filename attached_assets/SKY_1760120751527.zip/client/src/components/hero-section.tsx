import { Shield, CreditCard, Headphones } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export default function HeroSection() {
  const { t } = useLanguage();
  return (
    <section
      id="inicio"
      className="relative bg-gradient-to-r from-sky-red to-sky-coral text-white py-20"
      style={{
        backgroundImage: `linear-gradient(rgba(229, 62, 62, 0.8), rgba(255, 107, 107, 0.8)), url('https://images.unsplash.com/photo-1436491865332-7a61a109cc05?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=1920&h=1080')`,
        backgroundSize: 'cover',
        backgroundPosition: 'center'
      }}
      data-testid="hero-section"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl md:text-6xl font-bold mb-6" data-testid="hero-title">
            {t('hero.title')}
          </h1>
          <p className="text-xl md:text-2xl font-light max-w-3xl mx-auto" data-testid="hero-subtitle">
            {t('hero.subtitle')}
          </p>
        </div>
        
        {/* Trust badges */}
        <div className="flex flex-wrap justify-center items-center gap-8 mb-12">
          <div className="flex items-center bg-white bg-opacity-20 rounded-lg px-4 py-2" data-testid="trust-badge-secure">
            <Shield className="h-5 w-5 text-green-400 mr-2" />
            <span className="text-sm font-medium">{t('features.secure.title')}</span>
          </div>
          <div className="flex items-center bg-white bg-opacity-20 rounded-lg px-4 py-2" data-testid="trust-badge-payments">
            <CreditCard className="h-5 w-5 text-blue-400 mr-2" />
            <span className="text-sm font-medium">{t('features.payments')}</span>
          </div>
          <div className="flex items-center bg-white bg-opacity-20 rounded-lg px-4 py-2" data-testid="trust-badge-support">
            <Headphones className="h-5 w-5 text-yellow-400 mr-2" />
            <span className="text-sm font-medium">{t('features.support.title')}</span>
          </div>
        </div>
      </div>
    </section>
  );
}
