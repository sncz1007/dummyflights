import { Shield, CreditCard } from "lucide-react";
import skybudgetLogo from "@assets/ChatGPT Image 4 ago 2025, 04_57_45 p.m._1754453448045.png";
import { useLanguage } from "@/hooks/use-language";

export default function Footer() {
  const { t, language } = useLanguage();
  
  const scrollToSection = (href: string) => {
    if (href.startsWith("#")) {
      const targetId = href.substring(1);
      const element = document.getElementById(targetId);
      if (element) {
        element.scrollIntoView({ behavior: "smooth", block: "start" });
      } else {
        // Si no encuentra el elemento, navegar a la página principal con el anchor
        window.location.href = "/" + href;
      }
    }
  };

  return (
    <footer className="bg-sky-dark text-white py-12" data-testid="footer-main">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center mb-4">
              <img 
                src={skybudgetLogo} 
                alt="SkyBudget Logo" 
                className="h-10 w-auto mr-3"
              />
              <h4 className="text-2xl font-bold">SkyBudget</h4>
            </div>
            <p className="text-gray-300">
              {t('footer.about.text')}
            </p>
          </div>

          <div>
            <h5 className="text-lg font-semibold mb-4">{t('footer.links')}</h5>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-2">
                <div>
                  <button
                    onClick={() => scrollToSection("#inicio")}
                    className="text-gray-300 hover:text-white transition-colors block"
                    data-testid="footer-link-inicio"
                  >
                    {t('nav.home')}
                  </button>
                </div>
                <div>
                  <button
                    onClick={() => scrollToSection("#cotizar")}
                    className="text-gray-300 hover:text-white transition-colors block"
                    data-testid="footer-link-cotizar"
                  >
                    {t('nav.flights')}
                  </button>
                </div>
                <div>
                  <button
                    onClick={() => scrollToSection("#nosotros")}
                    className="text-gray-300 hover:text-white transition-colors block"
                    data-testid="footer-link-nosotros"
                  >
                    {t('nav.about')}
                  </button>
                </div>
              </div>
              <div className="space-y-2">
                <div>
                  <button
                    onClick={() => scrollToSection("#contacto")}
                    className="text-gray-300 hover:text-white transition-colors block"
                    data-testid="footer-link-contacto"
                  >
                    {t('nav.contact')}
                  </button>
                </div>
                <div>
                  <a 
                    href={language === 'es' ? '/privacidad.html' : '/privacy.html'} 
                    className="text-gray-300 hover:text-white transition-colors block" 
                    data-testid="footer-link-privacy"
                  >
                    {t('nav.privacy')}
                  </a>
                </div>
                <div>
                  <a 
                    href={language === 'es' ? '/terminos.html' : '/terms.html'} 
                    className="text-gray-300 hover:text-white transition-colors block" 
                    data-testid="footer-link-terms"
                  >
                    {t('nav.terms')}
                  </a>
                </div>
              </div>
            </div>
          </div>

          <div>
            <h5 className="text-lg font-semibold mb-4">{t('footer.contact')}</h5>
            <div className="space-y-2">
              <p className="text-gray-300 text-sm">
                <strong>Email:</strong> info@skybudgetfly.vip
              </p>
            </div>
          </div>
        </div>

        <div className="border-t border-gray-600 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-300 text-sm" data-testid="copyright">
              © 2025 SkyBudget. {t('footer.rights')}
            </p>
            <div className="flex items-center space-x-4 mt-4 md:mt-0">
              <div className="flex items-center">
                <Shield className="h-4 w-4 text-green-400 mr-2" />
                <span className="text-sm text-gray-300">{language === 'es' ? 'SSL Seguro' : 'Secure SSL'}</span>
              </div>
              <div className="flex items-center">
                <CreditCard className="h-4 w-4 text-blue-400 mr-2" />
                <span className="text-sm text-gray-300">{language === 'es' ? 'Pagos Seguros' : 'Secure Payments'}</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
