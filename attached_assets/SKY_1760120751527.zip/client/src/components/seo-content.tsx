import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";

export default function SEOContent() {
  const { t } = useLanguage();
  return (
    <section className="py-16 bg-white" data-testid="seo-content-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-sky-dark mb-4">
            {t('seo.guide.title')}
          </h2>
          <p className="text-lg text-gray-600">
            {t('seo.guide.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-sky-dark mb-3">
                {t('seo.guide.bestdays')}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {t('seo.guide.bestdays.desc')}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-sky-dark mb-3">
                {t('seo.guide.seasons')}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {t('seo.guide.seasons.desc')}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-sky-dark mb-3">
                {t('seo.guide.tips')}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {t('seo.guide.tips.desc')}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-sky-dark mb-3">
                {t('seo.guide.lastminute')}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {t('seo.guide.lastminute.desc')}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-sky-dark mb-3">
                {t('seo.guide.loyalty')}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {t('seo.guide.loyalty.desc')}
              </p>
            </CardContent>
          </Card>

          <Card className="hover:shadow-lg transition-shadow">
            <CardContent className="p-6">
              <h3 className="text-xl font-semibold text-sky-dark mb-3">
                {t('seo.guide.documentation')}
              </h3>
              <p className="text-gray-600 text-sm leading-relaxed">
                {t('seo.guide.documentation.desc')}
              </p>
            </CardContent>
          </Card>
        </div>

        <div className="mt-16">
          <h3 className="text-2xl font-bold text-sky-dark mb-6 text-center">
            {t('seo.guide.destinations')}
          </h3>
          <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4 text-center">
            {[
              "Madrid", "Barcelona", "Nueva York", "París", "Londres", "Roma",
              "Tokio", "Bangkok", "Miami", "Los Ángeles", "Cancún", "Dubai",
              "Amsterdam", "Berlin", "Estambul", "Buenos Aires", "Lima", "Bogotá"
            ].map((destination) => (
              <div key={destination} className="bg-sky-gray p-3 rounded-lg">
                <span className="text-sm font-medium text-gray-700">
                  {t('seo.guide.flightsto')} {destination}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}