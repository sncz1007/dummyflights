import { DollarSign, Shield, Headphones, CreditCard } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export default function WhyChooseUs() {
  const { t } = useLanguage();
  
  const features = [
    {
      icon: DollarSign,
      title: t('whychoose.bestprices'),
      description: t('whychoose.bestprices.desc')
    },
    {
      icon: Shield,
      title: t('whychoose.secure'),
      description: t('whychoose.secure.desc')
    },
    {
      icon: Headphones,
      title: t('whychoose.support'),
      description: t('whychoose.support.desc')
    },
    {
      icon: CreditCard,
      title: t('whychoose.payments'),
      description: t('whychoose.payments.desc')
    }
  ];
  return (
    <section id="nosotros" className="py-16 bg-sky-gray" data-testid="why-choose-us-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-sky-dark mb-4" data-testid="why-choose-us-title">
            {t('whychoose.title')}
          </h2>
          <p className="text-lg text-gray-600" data-testid="why-choose-us-subtitle">
            {t('whychoose.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {features.map((feature, index) => {
            const IconComponent = feature.icon;
            return (
              <div key={feature.title} className="text-center" data-testid={`feature-${index}`}>
                <div className="bg-sky-red text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4">
                  <IconComponent className="h-8 w-8" />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2" data-testid={`feature-title-${index}`}>
                  {feature.title}
                </h4>
                <p className="text-gray-600" data-testid={`feature-description-${index}`}>
                  {feature.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
