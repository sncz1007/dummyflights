import { useState, useEffect } from "react";
import { Check, ChevronsUpDown, MapPin } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useLanguage } from "@/hooks/use-language";
import { staticAirports, searchStaticAirports, type Airport } from "@/data/airports-static";

interface AirportSelectorProps {
  value?: string;
  onSelect: (airport: Airport | null) => void;
  placeholder?: string;
  disabled?: boolean;
  testId?: string;
}

export function AirportSelector({ 
  value, 
  onSelect, 
  placeholder = "Search airports...", 
  disabled = false,
  testId 
}: AirportSelectorProps) {
  const [open, setOpen] = useState(false);
  const [airports, setAirports] = useState<Airport[]>([]);
  const [loading, setLoading] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedAirport, setSelectedAirport] = useState<Airport | null>(null);
  const { t } = useLanguage();

  const searchAirports = async (query: string) => {
    if (query.length < 1) {
      setAirports([]);
      return;
    }

    setLoading(true);
    try {
      // Try API first
      const response = await fetch(`/api/airports/search?q=${encodeURIComponent(query)}`);
      if (response.ok) {
        const results = await response.json();
        setAirports(results);
      } else {
        // Fallback to static data if API fails
        console.log('Using static airport data (no backend connection)');
        const staticResults = searchStaticAirports(query);
        setAirports(staticResults);
      }
    } catch (error) {
      // Fallback to static data if API fails
      console.log('Using static airport data (backend unavailable)');
      const staticResults = searchStaticAirports(query);
      setAirports(staticResults);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    const timeoutId = setTimeout(() => {
      searchAirports(searchQuery);
    }, 150); // Faster response like Google Flights
    return () => clearTimeout(timeoutId);
  }, [searchQuery]);

  const handleSelect = (airport: Airport) => {
    setSelectedAirport(airport);
    onSelect(airport);
    setOpen(false);
  };

  const displayValue = selectedAirport 
    ? `${selectedAirport.iataCode} - ${selectedAirport.name} (${selectedAirport.city})`
    : value 
    ? value 
    : "";

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between"
          disabled={disabled}
          data-testid={testId}
        >
          <div className="flex items-center">
            <MapPin className="mr-2 h-4 w-4" />
            <span className="truncate">
              {displayValue || placeholder}
            </span>
          </div>
          <ChevronsUpDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-[400px] p-0">
        <Command>
          <CommandInput 
            placeholder={t('form.airport.search')} 
            value={searchQuery}
            onValueChange={setSearchQuery}
          />
          <CommandList>
            <CommandEmpty>
              {loading ? (
                <div className="flex items-center justify-center py-4">
                  <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-blue-600"></div>
                  <span className="ml-2">{t('form.airport.searching')}</span>
                </div>
              ) : searchQuery.length > 0 ? (
                <div className="py-4 text-center text-gray-500">
                  <div>{t('form.airport.notfound')}</div>
                  <div className="text-xs mt-1">
                    {t('form.airport.tryagain')}
                  </div>
                </div>
              ) : (
                <div className="py-4 text-center text-gray-500">
                  <div>{t('form.airport.search.placeholder')}</div>
                  <div className="text-xs mt-1">
                    {t('form.airport.search.example')}
                  </div>
                </div>
              )}
            </CommandEmpty>
            <CommandGroup>
              {airports.map((airport, index) => {
                // Clean city name for grouping (remove parenthetical info)
                const cleanCity = airport.city.split('(')[0].trim();
                const prevCleanCity = index > 0 ? airports[index - 1].city.split('(')[0].trim() : '';
                const showCityHeader = index === 0 || prevCleanCity !== cleanCity;
                const cityAirports = airports.filter(a => a.city.split('(')[0].trim() === cleanCity);
                
                return (
                  <div key={airport.iataCode}>
                    {showCityHeader && cityAirports.length > 1 && (
                      <div className="px-3 py-1 text-xs font-semibold text-blue-600 bg-blue-50 border-b">
                        {cleanCity}, {airport.country} - {cityAirports.length} {t('form.airport.multiple')}
                      </div>
                    )}
                    <CommandItem
                      value={`${airport.iataCode} ${airport.name} ${airport.city}`}
                      onSelect={() => handleSelect(airport)}
                      className="flex items-center justify-between hover:bg-blue-50 cursor-pointer p-2"
                    >
                      <div className="flex items-center flex-1">
                        <span className="font-bold text-white bg-red-600 px-2 py-1 rounded text-xs mr-3 min-w-[42px] text-center">
                          {airport.iataCode}
                        </span>
                        <div className="flex flex-col min-w-0 flex-1">
                          <span className="font-medium text-gray-900 text-sm truncate">
                            {airport.name}
                          </span>
                          <span className="text-xs text-gray-600 truncate">
                            📍 {airport.city}, {airport.country}
                          </span>
                        </div>
                      </div>
                      <Check
                        className={cn(
                          "h-4 w-4 text-blue-600 flex-shrink-0 ml-2",
                          value === airport.iataCode ? "opacity-100" : "opacity-0"
                        )}
                      />
                    </CommandItem>
                  </div>
                );
              })}
            </CommandGroup>
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
}