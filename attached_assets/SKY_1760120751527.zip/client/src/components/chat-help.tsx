import { useEffect } from 'react';

export default function ChatHelp() {
  useEffect(() => {
    // Brevo Chat Integration
    const script = document.createElement('script');
    script.type = 'text/javascript';
    script.async = true;
    script.src = 'https://conversations-widget.sendinblue.com/sib-conversations.js';
    
    script.onload = () => {
      if (window.sendinblue) {
        window.sendinblue.conversations({
          chatbox_id: '68915e2b46e26279710371e9',
          domain: 'https://conversations-widget.sendinblue.com'
        });
      }
    };

    document.head.appendChild(script);

    // Cleanup function
    return () => {
      if (document.head.contains(script)) {
        document.head.removeChild(script);
      }
    };
  }, []);

  return null; // This component doesn't render anything visible
}

// Type declaration for window.sendinblue
declare global {
  interface Window {
    sendinblue?: {
      conversations: (config: {
        chatbox_id: string;
        domain: string;
      }) => void;
    };
  }
}