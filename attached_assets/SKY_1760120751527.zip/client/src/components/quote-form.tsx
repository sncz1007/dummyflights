import { useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { useMutation } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { useToast } from "@/hooks/use-toast";
import { useLanguage } from "@/hooks/use-language";
import { apiRequest } from "@/lib/queryClient";
import { Link } from "wouter";
import { insertQuoteRequestSchema, type InsertQuoteRequest } from "@shared/schema";
import { Send } from "lucide-react";
import { AirportSelector } from "./airport-selector";
import { sendQuoteEmails } from "@/lib/email";

export default function QuoteForm() {
  const { toast } = useToast();
  const { t, language } = useLanguage();
  
  const form = useForm<InsertQuoteRequest>({
    resolver: zodResolver(insertQuoteRequestSchema),
    defaultValues: {
      flightType: "roundtrip",
      passengers: 1,
      name: "",
      email: "",
      phone: "",
      originAirport: "",
      destinationAirport: "",
      departureDate: "",
      returnDate: "",
    },
  });

  const flightType = form.watch("flightType");

  const submitQuoteMutation = useMutation({
    mutationFn: async (data: InsertQuoteRequest) => {
      // Generate a unique quote ID for static deployment
      const quoteId = 'quote-' + Date.now() + '-' + Math.random().toString(36).substr(2, 9);
      
      // Send emails directly via EmailJS (works in static deployment!)
      console.log('🔄 Sending quote via EmailJS...');
      
      const emailSuccess = await sendQuoteEmails({
        customerName: data.name,
        customerEmail: data.email,
        customerPhone: data.phone || '',
        originAirport: data.originAirport,
        destinationAirport: data.destinationAirport,
        departureDate: data.departureDate,
        returnDate: data.returnDate || '',
        flightType: data.flightType,
        passengers: data.passengers,
        departureTimeRange: data.departureTimeRange,
        departureFlightClass: data.departureFlightClass,
        returnTimeRange: data.returnTimeRange,
        returnFlightClass: data.returnFlightClass,
        quoteId: quoteId
      });
      
      if (!emailSuccess) {
        throw new Error('Failed to send quote request');
      }
      
      return { success: true, quoteId };
    },
    onSuccess: () => {
      toast({
        title: language === 'es' ? "🎉 ¡Solicitud Enviada Exitosamente!" : "🎉 Request Sent Successfully!",
        description: t('form.success'),
        duration: 8000, // 8 segundos en pantalla
      });
      form.reset();
    },
    onError: (error: any) => {
      toast({
        title: "Error",
        description: error.message || t('form.error'),
        variant: "destructive",
      });
    },
  });

  const onSubmit = (data: InsertQuoteRequest) => {
    submitQuoteMutation.mutate(data);
  };

  return (
    <section id="cotizar" className="py-16 bg-sky-gray" data-testid="quote-form-section">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-sky-dark mb-4" data-testid="quote-form-title">
            {t('form.title')}
          </h2>
          <div className="bg-red-50 border-l-4 border-sky-red p-4 mb-4 mx-auto max-w-2xl" data-testid="payment-notice">
            <p className="text-red-800 font-semibold text-base md:text-lg">
              {t('form.payment.notice')}
            </p>
          </div>
          <p className="text-lg text-gray-600" data-testid="quote-form-subtitle">
            {t('form.subtitle')}
          </p>
        </div>
        
        <Card className="shadow-xl">
          <CardContent className="p-8">
            <Form {...form}>
              <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                {/* Flight Type and Passengers */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="flightType"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('form.flighttype')}</FormLabel>
                        <FormControl>
                          <RadioGroup
                            onValueChange={field.onChange}
                            defaultValue={field.value}
                            className="flex space-x-4"
                            data-testid="radio-flight-type"
                          >
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="roundtrip" id="roundtrip" data-testid="radio-roundtrip" />
                              <label htmlFor="roundtrip" className="text-sm">{t('form.flighttype.roundtrip')}</label>
                            </div>
                            <div className="flex items-center space-x-2">
                              <RadioGroupItem value="oneway" id="oneway" data-testid="radio-oneway" />
                              <label htmlFor="oneway" className="text-sm">{t('form.flighttype.oneway')}</label>
                            </div>
                          </RadioGroup>
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="passengers"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('form.passengers')}</FormLabel>
                        <Select onValueChange={(value) => field.onChange(parseInt(value))} defaultValue={field.value?.toString()}>
                          <FormControl>
                            <SelectTrigger data-testid="select-passengers">
                              <SelectValue placeholder={t('form.passengers.placeholder')} />
                            </SelectTrigger>
                          </FormControl>
                          <SelectContent>
                            {[1, 2, 3, 4, 5, 6, 7, 8, 9, 10].map((num) => (
                              <SelectItem key={num} value={num.toString()}>
                                {num === 1 ? t('form.passengers.1') : 
                                 num === 2 ? t('form.passengers.2') :
                                 num === 3 ? t('form.passengers.3') :
                                 num === 4 ? t('form.passengers.4') :
                                 num === 5 ? t('form.passengers.5') :
                                 t('form.passengers.6')}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Origin and Destination */}
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <FormField
                    control={form.control}
                    name="originAirport"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('form.origin')}</FormLabel>
                        <FormControl>
                          <AirportSelector
                            value={field.value}
                            onSelect={(airport) => field.onChange(airport?.iataCode || "")}
                            placeholder={t('form.origin.placeholder')}
                            testId="selector-origin-airport"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={form.control}
                    name="destinationAirport"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>{t('form.destination')}</FormLabel>
                        <FormControl>
                          <AirportSelector
                            value={field.value}
                            onSelect={(airport) => field.onChange(airport?.iataCode || "")}
                            placeholder={t('form.destination.placeholder')}
                            testId="selector-destination-airport"
                          />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>

                {/* Departure Flight Details */}
                <div className="border-t pt-6">
                  <h4 className="text-lg font-semibold text-sky-dark mb-4">
                    {language === 'es' ? 'Vuelo de Ida' : 'Departure Flight'}
                  </h4>
                  
                  {/* Desktop Layout: Date, Time, Class in single row */}
                  <div className="hidden md:grid md:grid-cols-3 gap-6">
                    <FormField
                      control={form.control}
                      name="departureDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('form.departure')}</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} data-testid="input-departure-date" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="departureTimeRange"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{language === 'es' ? 'Horario' : 'Time'}</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-departure-time-range">
                                <SelectValue placeholder={language === 'es' ? 'Horario preferido' : 'Preferred time'} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="00:00-04:00">00:00 - 04:00</SelectItem>
                              <SelectItem value="04:00-08:00">04:00 - 08:00</SelectItem>
                              <SelectItem value="08:00-12:00">08:00 - 12:00</SelectItem>
                              <SelectItem value="12:00-16:00">12:00 - 16:00</SelectItem>
                              <SelectItem value="16:00-20:00">16:00 - 20:00</SelectItem>
                              <SelectItem value="20:00-00:00">20:00 - 00:00</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="departureFlightClass"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{language === 'es' ? 'Clase' : 'Flight Type'}</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-departure-flight-class">
                                <SelectValue placeholder={language === 'es' ? 'Clase' : 'Class'} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Main">Main</SelectItem>
                              <SelectItem value="Premium">Premium</SelectItem>
                              <SelectItem value="Business">Business</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  {/* Mobile Layout: Stacked vertically */}
                  <div className="md:hidden space-y-4">
                    <FormField
                      control={form.control}
                      name="departureDate"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('form.departure')}</FormLabel>
                          <FormControl>
                            <Input type="date" {...field} data-testid="input-departure-date-mobile" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="departureTimeRange"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{language === 'es' ? 'Horario' : 'Time'}</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-departure-time-range-mobile">
                                <SelectValue placeholder={language === 'es' ? 'Horario preferido' : 'Preferred time'} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="00:00-04:00">00:00 - 04:00</SelectItem>
                              <SelectItem value="04:00-08:00">04:00 - 08:00</SelectItem>
                              <SelectItem value="08:00-12:00">08:00 - 12:00</SelectItem>
                              <SelectItem value="12:00-16:00">12:00 - 16:00</SelectItem>
                              <SelectItem value="16:00-20:00">16:00 - 20:00</SelectItem>
                              <SelectItem value="20:00-00:00">20:00 - 00:00</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="departureFlightClass"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{language === 'es' ? 'Clase' : 'Flight Type'}</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger data-testid="select-departure-flight-class-mobile">
                                <SelectValue placeholder={language === 'es' ? 'Clase' : 'Class'} />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="Main">Main</SelectItem>
                              <SelectItem value="Premium">Premium</SelectItem>
                              <SelectItem value="Business">Business</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Return Flight Details - Only show for Round Trip */}
                {flightType === "roundtrip" && (
                  <div className="border-t pt-6">
                    <h4 className="text-lg font-semibold text-sky-dark mb-4">
                      {language === 'es' ? 'Vuelo de Vuelta' : 'Return Flight'}
                    </h4>
                    
                    {/* Desktop Layout: Date, Time, Class in single row */}
                    <div className="hidden md:grid md:grid-cols-3 gap-6">
                      <FormField
                        control={form.control}
                        name="returnDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t('form.return')}</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} data-testid="input-return-date" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="returnTimeRange"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{language === 'es' ? 'Horario' : 'Time'}</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-return-time-range">
                                  <SelectValue placeholder={language === 'es' ? 'Horario preferido' : 'Preferred time'} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="00:00-04:00">00:00 - 04:00</SelectItem>
                                <SelectItem value="04:00-08:00">04:00 - 08:00</SelectItem>
                                <SelectItem value="08:00-12:00">08:00 - 12:00</SelectItem>
                                <SelectItem value="12:00-16:00">12:00 - 16:00</SelectItem>
                                <SelectItem value="16:00-20:00">16:00 - 20:00</SelectItem>
                                <SelectItem value="20:00-00:00">20:00 - 00:00</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="returnFlightClass"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{language === 'es' ? 'Clase' : 'Flight Type'}</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-return-flight-class">
                                  <SelectValue placeholder={language === 'es' ? 'Clase' : 'Class'} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Main">Main</SelectItem>
                                <SelectItem value="Premium">Premium</SelectItem>
                                <SelectItem value="Business">Business</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>

                    {/* Mobile Layout: Stacked vertically */}
                    <div className="md:hidden space-y-4">
                      <FormField
                        control={form.control}
                        name="returnDate"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{t('form.return')}</FormLabel>
                            <FormControl>
                              <Input type="date" {...field} data-testid="input-return-date-mobile" />
                            </FormControl>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="returnTimeRange"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{language === 'es' ? 'Horario' : 'Time'}</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-return-time-range-mobile">
                                  <SelectValue placeholder={language === 'es' ? 'Horario preferido' : 'Preferred time'} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="00:00-04:00">00:00 - 04:00</SelectItem>
                                <SelectItem value="04:00-08:00">04:00 - 08:00</SelectItem>
                                <SelectItem value="08:00-12:00">08:00 - 12:00</SelectItem>
                                <SelectItem value="12:00-16:00">12:00 - 16:00</SelectItem>
                                <SelectItem value="16:00-20:00">16:00 - 20:00</SelectItem>
                                <SelectItem value="20:00-00:00">20:00 - 00:00</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />

                      <FormField
                        control={form.control}
                        name="returnFlightClass"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>{language === 'es' ? 'Clase' : 'Flight Type'}</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger data-testid="select-return-flight-class-mobile">
                                  <SelectValue placeholder={language === 'es' ? 'Clase' : 'Class'} />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="Main">Main</SelectItem>
                                <SelectItem value="Premium">Premium</SelectItem>
                                <SelectItem value="Business">Business</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    </div>
                  </div>
                )}

                {/* Contact Information */}
                <div className="border-t pt-6">
                  <h4 className="text-lg font-semibold text-gray-900 mb-4">{language === 'es' ? 'Información de Contacto' : 'Contact Information'}</h4>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <FormField
                      control={form.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('form.name')}</FormLabel>
                          <FormControl>
                            <Input placeholder={t('form.name.placeholder')} {...field} data-testid="input-name" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={form.control}
                      name="email"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('form.email')}</FormLabel>
                          <FormControl>
                            <Input type="email" placeholder={t('form.email.placeholder')} {...field} data-testid="input-email" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <div className="mt-6">
                    <FormField
                      control={form.control}
                      name="phone"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>{t('form.phone')}</FormLabel>
                          <FormControl>
                            <Input type="tel" placeholder={t('form.phone.placeholder')} {...field} data-testid="input-phone" />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>

                {/* Terms and Submit */}
                <div className="space-y-4">
                  <div className="flex items-start space-x-2">
                    <Checkbox id="terms" required data-testid="checkbox-terms" />
                    <label htmlFor="terms" className="text-sm text-gray-600 leading-relaxed">
                      {language === 'es' ? 'Acepto los' : 'I accept the'}{" "}
                      <a href={language === 'es' ? '/terminos.html' : '/terms.html'} className="text-sky-red hover:underline" target="_blank" rel="noopener noreferrer">
                        {language === 'es' ? 'términos y condiciones' : 'terms and conditions'}
                      </a>{" "}
                      {language === 'es' ? 'y la' : 'and the'}{" "}
                      <a href={language === 'es' ? '/privacidad.html' : '/privacy.html'} className="text-sky-red hover:underline" target="_blank" rel="noopener noreferrer">
                        {language === 'es' ? 'política de privacidad' : 'privacy policy'}
                      </a>
                    </label>
                  </div>
                  
                  <Button
                    type="submit"
                    className="w-full bg-sky-red hover:bg-red-600 text-white font-semibold py-4 px-8 rounded-lg transition-colors duration-200"
                    disabled={submitQuoteMutation.isPending}
                    data-testid="button-submit-quote"
                  >
                    {submitQuoteMutation.isPending ? (
                      t('form.submitting')
                    ) : (
                      <>
                        <Send className="h-5 w-5 mr-2" />
                        {t('form.submit')}
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Form>
          </CardContent>
        </Card>
      </div>
    </section>
  );
}
