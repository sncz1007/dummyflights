import { Star } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export default function Testimonials() {
  const { t, language } = useLanguage();
  
  const testimonials = [
    {
      name: language === 'es' ? "Carlos Rodríguez" : "James Wilson", 
      avatar: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      comment: t('testimonials.1.text')
    },
    {
      name: language === 'es' ? "María González" : "Sarah Johnson",
      avatar: "https://www.blogdelfotografo.com/wp-content/uploads/2019/08/mujer-retrato.webp", 
      comment: t('testimonials.2.text')
    },
    {
      name: language === 'es' ? "Luis Fernández" : "Michael Chen",
      avatar: "https://images.unsplash.com/photo-1472099645785-5658abf4ff4e?ixlib=rb-4.0.3&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=100&h=100",
      comment: t('testimonials.3.text')
    }
  ];


  
  return (
    <section className="py-16 bg-white" data-testid="testimonials-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-sky-dark mb-4" data-testid="testimonials-title">
            {t('testimonials.title')}
          </h2>
          <p className="text-lg text-gray-600" data-testid="testimonials-subtitle">
            {language === 'es' ? 'Más de 10,000 clientes satisfechos nos respaldan' : 'Over 10,000 satisfied customers trust us'}
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {testimonials.map((testimonial, index) => (
            <div key={testimonial.name} className="bg-gray-50 rounded-xl p-6" data-testid={`testimonial-${index}`}>
              <div className="flex items-center mb-4">
                <img 
                  src={testimonial.avatar} 
                  alt={`${language === 'es' ? 'Cliente' : 'Customer'} ${testimonial.name}`}
                  className="w-12 h-12 rounded-full object-cover mr-4"
                  data-testid={`testimonial-avatar-${index}`}
                />
                <div>
                  <h5 className="font-semibold text-gray-900" data-testid={`testimonial-name-${index}`}>
                    {testimonial.name}
                  </h5>
                  <div className="flex text-yellow-400">
                    {[...Array(5)].map((_, i) => (
                      <Star key={i} className="h-4 w-4 fill-current" />
                    ))}
                  </div>
                </div>
              </div>
              <p className="text-gray-600" data-testid={`testimonial-comment-${index}`}>
                "{testimonial.comment}"
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
