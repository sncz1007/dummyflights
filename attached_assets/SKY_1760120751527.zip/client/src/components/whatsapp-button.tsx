import { MessageCircle } from "lucide-react";

export default function WhatsAppButton() {
  const whatsappNumber = "+15551234567";
  const message = "Hola, me interesa cotizar un vuelo";
  const whatsappUrl = `https://wa.me/${whatsappNumber}?text=${encodeURIComponent(message)}`;

  return (
    <a
      href={whatsappUrl}
      target="_blank"
      rel="noopener noreferrer"
      className="fixed bottom-6 right-20 bg-green-500 text-white w-16 h-16 rounded-full flex items-center justify-center shadow-lg hover:bg-green-600 transition-colors duration-200 z-50"
      data-testid="whatsapp-button"
    >
      <MessageCircle className="h-8 w-8" />
    </a>
  );
}
