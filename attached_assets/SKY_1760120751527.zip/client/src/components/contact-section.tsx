import { Mail } from "lucide-react";
import { useLanguage } from "@/hooks/use-language";

export default function ContactSection() {
  const { t } = useLanguage();
  
  const contactMethods = [
    {
      icon: Mail,
      title: t('contact.email'),
      contact: "info@skybudgetfly.vip",
      description: t('contact.email.response')
    }
  ];
  return (
    <section id="contacto" className="py-16 bg-sky-gray" data-testid="contact-section">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h3 className="text-3xl md:text-4xl font-bold text-sky-dark mb-4" data-testid="contact-title">
            {t('contact.title')}
          </h3>
          <p className="text-lg text-gray-600" data-testid="contact-subtitle">
            {t('contact.subtitle')}
          </p>
        </div>

        <div className="grid grid-cols-1 gap-8 max-w-md mx-auto">
          {contactMethods.map((method, index) => {
            const IconComponent = method.icon;
            const bgColor = "bg-sky-red";
            
            return (
              <div key={method.title} className="text-center" data-testid={`contact-method-${index}`}>
                <div className={`${bgColor} text-white w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-4`}>
                  <IconComponent className="h-8 w-8" />
                </div>
                <h4 className="text-xl font-semibold text-gray-900 mb-2" data-testid={`contact-method-title-${index}`}>
                  {method.title}
                </h4>
                <p className="text-gray-600 font-medium" data-testid={`contact-method-contact-${index}`}>
                  {method.contact}
                </p>
                <p className="text-gray-600 text-sm" data-testid={`contact-method-description-${index}`}>
                  {method.description}
                </p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
