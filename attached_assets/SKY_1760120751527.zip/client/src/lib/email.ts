// EmailJS frontend service - works from browser
import emailjs from '@emailjs/browser';

// Initialize EmailJS with public key
const EMAILJS_PUBLIC_KEY = import.meta.env.VITE_EMAILJS_PUBLIC_KEY;
const EMAILJS_SERVICE_ID = import.meta.env.VITE_EMAILJS_SERVICE_ID;
const EMAILJS_TEMPLATE_ID = import.meta.env.VITE_EMAILJS_TEMPLATE_ID;

if (EMAILJS_PUBLIC_KEY) {
  emailjs.init(EMAILJS_PUBLIC_KEY);
}

export interface QuoteEmailData {
  customerName: string;
  customerEmail: string;
  customerPhone: string;
  originAirport: string;
  destinationAirport: string;
  departureDate: string;
  returnDate?: string;
  flightType: string;
  passengers: number;
  departureTimeRange?: string;
  departureFlightClass?: string;
  returnTimeRange?: string;
  returnFlightClass?: string;
  quoteId: string;
}

export async function sendQuoteEmails(data: QuoteEmailData): Promise<boolean> {
  if (!EMAILJS_SERVICE_ID || !EMAILJS_TEMPLATE_ID || !EMAILJS_PUBLIC_KEY) {
    console.log('EmailJS no configurado');
    return false;
  }

  try {
    console.log('📧 Enviando cotización a Gmail...');

    // Solo email de cotización a tu Gmail - sin confirmación automática
    const businessEmail = {
      to_email: 'skybudgetflybooking@gmail.com',
      from_name: data.customerName,
      from_email: data.customerEmail,
      subject: `Nueva cotización: ${data.originAirport} → ${data.destinationAirport}`,
      message: `NUEVA COTIZACIÓN DE VUELO - SkyBudget

DATOS DEL CLIENTE:
Nombre: ${data.customerName}
Email: ${data.customerEmail}
Teléfono: ${data.customerPhone || 'No proporcionado'}

DETALLES DEL VUELO:
• Origen: ${data.originAirport}
• Destino: ${data.destinationAirport}
• Fecha de ida: ${data.departureDate}
${data.returnDate ? `• Fecha de vuelta: ${data.returnDate}` : ''}
• Tipo: ${data.flightType === 'roundtrip' ? 'Ida y vuelta' : 'Solo ida'}
• Pasajeros: ${data.passengers}

VUELO DE IDA:
${data.departureTimeRange ? `• Horario preferido: ${data.departureTimeRange}` : ''}
${data.departureFlightClass ? `• Clase: ${data.departureFlightClass}` : ''}

${data.flightType === 'roundtrip' && (data.returnTimeRange || data.returnFlightClass) ? 
`VUELO DE VUELTA:
${data.returnTimeRange ? `• Horario preferido: ${data.returnTimeRange}` : ''}
${data.returnFlightClass ? `• Clase: ${data.returnFlightClass}` : ''}` : ''}

Referencia: ${data.quoteId}
Fecha: ${new Date().toLocaleString('es-ES')}

--- 
Para responder al cliente, usa: ${data.customerEmail}
Enviado desde formulario web SkyBudget`
    };

    await emailjs.send(EMAILJS_SERVICE_ID, EMAILJS_TEMPLATE_ID, businessEmail);
    console.log('✅ Cotización enviada a Gmail - responderás manualmente al cliente');

    return true;
    
  } catch (error) {
    console.error('❌ Error enviando email:', error);
    return false;
  }
}