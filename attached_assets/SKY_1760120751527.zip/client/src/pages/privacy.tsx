import { useEffect } from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";

export default function Privacy() {
  const { t } = useLanguage();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <div className="min-h-screen bg-white privacy-page standalone-page">
      <Header />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-sky-dark">
              {t('privacy.title')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-gray-700">
            <p className="text-lg">{t('privacy.intro')}</p>
            
            <section>
              <h3 className="text-xl font-semibold mb-3">{t('privacy.collection.title')}</h3>
              <p>{t('privacy.collection.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('privacy.use.title')}</h3>
              <p>{t('privacy.use.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('privacy.sharing.title')}</h3>
              <p>{t('privacy.sharing.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('privacy.security.title')}</h3>
              <p>{t('privacy.security.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('privacy.cookies.title')}</h3>
              <p>{t('privacy.cookies.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('privacy.contact.title')}</h3>
              <p>{t('privacy.contact.content')} <strong>info@skybudgetfly.vip</strong></p>
            </section>

            <section className="text-sm text-gray-600">
              <p>Última actualización: Agosto 2025</p>
            </section>
          </CardContent>
        </Card>
      </div>
      <Footer />
    </div>
  );
}
