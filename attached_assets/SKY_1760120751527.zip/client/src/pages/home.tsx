import Header from "@/components/header";
import Footer from "@/components/footer";
import HeroSection from "@/components/hero-section";
import QuoteForm from "@/components/quote-form";
import Destinations from "@/components/destinations";
import WhyChooseUs from "@/components/why-choose-us";
import Testimonials from "@/components/testimonials";
import ContactSection from "@/components/contact-section";

import SEOContent from "@/components/seo-content";
import ChatHelp from "@/components/chat-help";

export default function Home() {
  return (
    <div className="min-h-screen bg-white">
      <Header />
      <HeroSection />
      <QuoteForm />
      <Destinations />
      <WhyChooseUs />
      <Testimonials />
      <SEOContent />
      <ContactSection />
      <Footer />
      <ChatHelp />
    </div>
  );
}
