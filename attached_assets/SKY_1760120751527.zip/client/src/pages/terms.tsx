import { useEffect } from "react";
import Header from "@/components/header";
import Footer from "@/components/footer";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { useLanguage } from "@/hooks/use-language";

export default function Terms() {
  const { t } = useLanguage();
  
  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);
  return (
    <div className="min-h-screen bg-white terms-page standalone-page">
      <Header />
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <Card>
          <CardHeader>
            <CardTitle className="text-3xl font-bold text-sky-dark">
              {t('terms.title')}
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-6 text-gray-700">
            <p className="text-lg">{t('terms.intro')}</p>
            
            <section>
              <h3 className="text-xl font-semibold mb-3">{t('terms.services.title')}</h3>
              <p>{t('terms.services.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('terms.quotes.title')}</h3>
              <p>{t('terms.quotes.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('terms.booking.title')}</h3>
              <p>{t('terms.booking.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('terms.cancellation.title')}</h3>
              <p>{t('terms.cancellation.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('terms.liability.title')}</h3>
              <p>{t('terms.liability.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('terms.changes.title')}</h3>
              <p>{t('terms.changes.content')}</p>
            </section>

            <section>
              <h3 className="text-xl font-semibold mb-3">{t('terms.contact.title')}</h3>
              <p>{t('terms.contact.content')} <strong>info@skybudgetfly.vip</strong></p>
            </section>

            <section className="text-sm text-gray-600">
              <p>Última actualización: Agosto 2025</p>
            </section>
          </CardContent>
        </Card>
      </div>
      <Footer />
    </div>
  );
}
