# Configuración de Brevo Chat para SkyBudget

## Pasos para configurar tu chat en vivo con Brevo

### 1. Crear cuenta en Brevo
1. Ve a https://www.brevo.com/
2. Haz clic en "Sign Up Free"
3. Registra tu cuenta con el email: info@skybudgetfly.com
4. Confirma tu email y completa el registro

### 2. Activar Conversations (Chat)
1. En el dashboard de Brevo, ve a "Conversations"
2. Haz clic en "Get Started" o "Activate"
3. Configura tu workspace:
   - Nombre: "SkyBudget"
   - Sitio web: tu dominio (ej: https://skybudget.replit.app)
   - Industria: "Travel & Tourism"

### 3. Obtener tu ID de instalación
1. Ve a "Conversations" > "Settings" > "Installation"
2. Copia tu ID de instalación (será algo como: 'abc123def456')
3. Reemplaza 'TU_BREVO_ID_AQUI' en el archivo index.html con tu ID real

### 4. Personalizar el chat
En el dashboard de Brevo:

#### Configuración básica:
- **Conversations > Settings > Widget**: Personaliza colores (ya está configurado con rojo #e53e3e)
- **Settings > Welcome Message**: El mensaje ya está configurado en español
- **Settings > Triggers**: Configura cuándo mostrar el chat

#### Mensaje de bienvenida (ya configurado):
```
¡Hola! 👋 Bienvenido a SkyBudget. ¿En qué puedo ayudarte con tu próximo viaje?
```

#### Configuración recomendada:
- **Widget Settings**: El color rojo y posición ya están configurados
- **Operating Hours**: Configura tu horario de atención
- **Auto-messages**: Configura respuestas automáticas
- **Team Management**: Invita a otros agentes si necesitas

### 5. Aplicación móvil
Descarga la app de Brevo en tu teléfono para responder chats desde cualquier lugar:
- iOS: https://apps.apple.com/app/brevo/id1150333768
- Android: https://play.google.com/store/apps/details?id=com.sendinblue.androidapp

### 6. Reemplazar el ID
Busca esta línea en client/index.html:
```javascript
w.sendinblueConversations.accountId = 'TU_BREVO_ID_AQUI';
```

Reemplázala con tu Account ID real de Brevo (normalmente es un número).

## Ventajas de Brevo Chat
- Integrado con email marketing de Brevo
- Respuesta inmediata a clientes
- Aumenta conversiones hasta 40%
- Genera más confianza y leads de calidad
- Plan gratuito generoso (hasta 300 chats/mes)
- Integración con CRM automático

## Funciones especiales de Brevo
- **Automation**: Respuestas automáticas basadas en páginas visitadas
- **Lead Scoring**: Califica automáticamente la calidad del lead
- **Email Follow-up**: Envía emails automáticos después del chat
- **Analytics**: Estadísticas detalladas de conversaciones
- **Mobile Apps**: Apps nativas para iOS y Android

## Consejos para usar Brevo Chat efectivamente
1. **Responde rápido**: Los usuarios esperan respuesta en menos de 2 minutos
2. **Usa automatización**: Configura respuestas automáticas para preguntas frecuentes
3. **Recolecta emails**: Brevo automáticamente guarda los contactos
4. **Segmenta leads**: Usa las etiquetas para categorizar tipos de consultas
5. **Follow-up por email**: Usa la integración para enviar cotizaciones por email