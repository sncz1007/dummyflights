# SkyBudget Flight Quote Platform

## Overview

SkyBudget is a modern flight quotation platform built as a full-stack web application. The system allows users to submit flight quote requests through an intuitive form interface and automatically sends email notifications to the business team. The platform is designed as a lead generation tool for a travel agency, featuring a professional landing page with flight search capabilities, destination showcases, customer testimonials, and comprehensive SEO optimization for Google rankings.

## Recent Changes (August 2025)

### Mobile UX Optimization and Chat Widget Fix (August 15, 2025)
- Fixed chat widget gigantic size issue on iPhone devices in US
- Added comprehensive CSS and JavaScript controls for Brevo chat widget sizing
- Optimized language selector size for mobile - no longer covers logo
- Centered toast confirmation messages for mobile visibility
- Enhanced mobile experience without affecting desktop or form functionality
- All optimizations preserve EmailJS functionality completely

### Final Complete Package with Favicon and Mobile Language Selector (August 13, 2025)
- Added custom favicon with red airplane design for browser tabs
- Fixed mobile language selector - now appears in hamburger menu with separator line
- Added more Latin American airports including Pereira (PEI), Medellín Olaya Herrera (EOH)
- Enhanced airport search with 600+ international airports for static deployment
- Preserved EmailJS functionality completely - no changes to working form
- Confirmed bilingual subpages (terms/privacy) work correctly with language selector
- Final complete package: skybudgetfly-website-final.tar.gz

### Static Deployment with EmailJS-Only Fixed (August 11, 2025)
- Modified quote form to work without backend API calls
- EmailJS now works directly from frontend for static hosting
- Eliminated `/api/quote-request` dependency for skybudgetfly.com deployment
- Form generates unique quote IDs client-side

### Complete Navigation System Fixed (August 11, 2025)
- Improved navigation functions in header and footer components
- Smart redirection system: if section not found, redirects to main page with anchor
- Fixed navigation issues in terms and privacy subpages
- Navigation now works seamlessly across all pages (main, terms, privacy)
- Compiled final version: skybudget-website-final-complete.tar.gz with all features
- Created comprehensive hosting instructions for server deployment

## Recent Changes (August 2025)

### Complete Bilingual Translation System (August 9, 2025)
- Complete English-Spanish translation system implemented throughout website
- English set as primary default language - always loads first
- All forms, buttons, labels, and content now use dynamic translations
- Enhanced success message for both languages mentioning 40% discount
- Footer updated with proper multilingual support and contact information
- Header navigation fully translated and cleaned up
- Form validation messages and placeholders in both languages
- Passenger selection and flight type options properly translated
- Professional contact information updated throughout (skybudgetfly@gmail.com)
- Terms and Privacy pages fully bilingual with proper scroll behavior

### Simple Gmail Email System (August 9, 2025)
- EmailJS frontend integration sending single email to Gmail
- Only business notifications to skybudgetfly@gmail.com with customer details
- No automatic customer confirmations - manual responses only
- Brevo integration completely removed - Gmail-only solution
- Customer email clearly displayed for manual response
- Fast and reliable single-email system without reply-to complications

### Google Flights-Style Airport Search (August 6, 2025)
- Completely rebuilt airport search with intelligent predictive functionality
- Real-time search results from first character typed (150ms response time)
- Advanced SQL queries using multiple search strategies (exact match, starts with, contains, regex)
- Smart grouping by city when multiple airports exist (Miami shows 3 airports, London shows 7+)
- Enhanced UI with IATA codes highlighted in red and visual city groupings
- Supports international searches: Miami, Cali Colombia, New York (JFK/LGA), Paris (CDG/Orly), Madrid, London
- PostgreSQL database with 5,164 worldwide airports loaded and optimized

### Custom SkyBudget Branding Update (August 6, 2025)
- Replaced all generic airplane icons with custom SkyBudget logo throughout site
- Updated header and footer with professional logo featuring red airplane and clouds
- Enhanced visual consistency across all components
- Improved brand recognition and professional appearance

### Email System Update (August 6, 2025)
- Updated all email references from shinebrowninfo@gmail.com to skybudgetfly@gmail.com
- Modified quote form backend to send requests to new email address
- Updated privacy policy, terms of service, and all documentation
- Regenerated compiled website package with new email configuration

### SEO Optimization Complete
- Added comprehensive meta tags, Open Graph, and Twitter Card data
- Implemented Schema.org structured data for travel agency
- Created sitemap.xml and robots.txt for search engine crawling
- Optimized all headings with keyword-rich content (vuelos baratos, billetes de avión)
- Added SEO content section with travel tips and popular destinations
- Updated contact email to skybudgetfly@gmail.com throughout the platform

### Live Chat Integration
- Integrated Brevo Chat (Sendinblue) widget for instant customer support
- Configured in Spanish with SkyBudget branding and red color scheme
- Replaces previous Tawk.to integration for better email marketing integration
- Includes automated lead capture and CRM integration

## User Preferences

Preferred communication style: Simple, everyday language.
Email configuration: Quote requests are sent to skybudgetfly@gmail.com (Brevo-linked), contact section shows info@skybudgetfly.com
Airport search requirements: Must work exactly like Google Flights with predictive results showing all airports for a city
Branding preference: Custom SkyBudget logo with red airplane and clouds design
User feedback: "Esta perfecto, me encanta" - very satisfied with current Google Flights-style airport search implementation

## System Architecture

### Frontend Architecture
The client is built with React and TypeScript, utilizing a component-based architecture with modern UI patterns. The application uses Vite as the build tool and development server, providing fast hot module replacement and optimized builds. The UI is constructed with shadcn/ui components built on top of Radix UI primitives, styled with Tailwind CSS for consistent and responsive design.

**Key Frontend Decisions:**
- **React with TypeScript**: Provides type safety and better developer experience
- **Vite**: Chosen for fast development builds and modern ES module support
- **shadcn/ui + Radix UI**: Ensures accessible, customizable components with consistent styling
- **Tailwind CSS**: Enables rapid UI development with utility-first approach
- **Wouter**: Lightweight client-side routing solution
- **React Hook Form + Zod**: Form handling with runtime validation and type safety
- **TanStack Query**: Server state management and data fetching

### Backend Architecture
The server follows an Express.js REST API pattern with TypeScript for type safety. The application uses a modular route structure and implements middleware for request logging and error handling. The server includes both development and production configurations with Vite integration for seamless full-stack development.

**Key Backend Decisions:**
- **Express.js**: Mature and flexible web framework for Node.js
- **TypeScript**: Maintains type consistency across the full stack
- **Modular routing**: Separates concerns and improves maintainability
- **Memory storage with interface**: Allows easy database migration later
- **Middleware pattern**: Provides clean separation of cross-cutting concerns

### Data Storage
Currently implements an in-memory storage solution with a well-defined interface that can be easily swapped for a persistent database. The storage layer is designed with Drizzle ORM schemas that support PostgreSQL, indicating preparation for database migration.

**Storage Design Rationale:**
- **Interface-based storage**: Enables easy migration from memory to database
- **Drizzle ORM**: Provides type-safe database operations and schema management
- **PostgreSQL ready**: Configuration exists for production database deployment

### Form Handling and Validation
The quote request form uses React Hook Form for efficient form state management combined with Zod for both client and server-side validation. This ensures data consistency and provides immediate user feedback.

**Validation Strategy:**
- **Shared schemas**: Uses Drizzle-Zod to generate validation schemas from database models
- **Client-server consistency**: Same validation rules applied on both sides
- **Type safety**: Ensures runtime validation matches TypeScript types

### Email Integration
The platform integrates with SMTP services for automated email notifications when quote requests are submitted. The email system is configurable through environment variables and includes proper error handling.

**Email Architecture:**
- **Nodemailer**: Industry-standard email sending library
- **SMTP configuration**: Supports various email providers through environment variables
- **Error handling**: Graceful degradation if email service is unavailable

### Styling and Design System
The application implements a cohesive design system using CSS custom properties for theming and Tailwind CSS for component styling. The design supports both light and dark themes with a red-based color palette reflecting the SkyBudget brand.

**Design Decisions:**
- **CSS custom properties**: Enables dynamic theming and consistent color usage
- **Component-level styling**: Maintains encapsulation while allowing customization
- **Responsive design**: Mobile-first approach with breakpoint-based layouts

## External Dependencies

### UI and Component Libraries
- **@radix-ui/***: Accessible, unstyled UI primitives for complex components
- **shadcn/ui**: Pre-built component library with consistent styling
- **lucide-react**: Modern icon library with tree-shaking support

### Database and ORM
- **drizzle-orm**: Type-safe SQL query builder and ORM
- **@neondatabase/serverless**: PostgreSQL driver optimized for serverless environments
- **drizzle-kit**: Database migration and schema management tools

### Form Management
- **react-hook-form**: Performant form library with minimal re-renders
- **@hookform/resolvers**: Integration layer for external validation libraries
- **zod**: Runtime type validation and schema definition

### Development and Build Tools
- **vite**: Fast build tool and development server
- **@vitejs/plugin-react**: React integration for Vite
- **@replit/vite-plugin-***: Replit-specific development enhancements
- **tsx**: TypeScript execution engine for Node.js

### Email Services
- **nodemailer**: Email sending library with SMTP support
- **@types/nodemailer**: TypeScript definitions for nodemailer

### State Management and Data Fetching
- **@tanstack/react-query**: Server state management and caching
- **wouter**: Lightweight client-side routing

### Styling and CSS
- **tailwindcss**: Utility-first CSS framework
- **autoprefixer**: CSS vendor prefix automation
- **class-variance-authority**: Type-safe variant API for styling
- **clsx**: Conditional CSS class name utility