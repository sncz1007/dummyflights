# SkyBudget - Instrucciones de Hosting

## Archivos para Subir al Servidor
Descomprime `skybudget-website-with-static-airports.tar.gz` y sube todo el contenido a tu carpeta **public** del servidor.

**IMPORTANTE:** Este archivo incluye los datos de aeropuertos integrados para que funcione sin backend.

## Contenido del Archivo
```
skybudget-website-with-static-airports.tar.gz
├── index.html (página principal)
├── assets/
│   ├── index-BpCQUvPU.js (JavaScript compilado con librerías + datos de aeropuertos)
│   ├── index-DnZgqlQt.css (CSS compilado con Tailwind)
│   ├── IMG_9390_1754454830511-Cjy8jh9W.jpeg (Logo SkyBudget)
│   └── ChatGPT Image 4 ago 2025_ 04_57_45 p.m._1754453448045-DxTXx4sD.png (Imagen hero)
├── robots.txt (SEO para motores de búsqueda)
└── sitemap.xml (Mapa del sitio para Google)
```

## Características Incluidas
✅ **Sitio Completamente Bilingüe** (Inglés/Español - Inglés por defecto)
✅ **Navegación Funcional** - Menú y footer funcionan en todas las páginas
✅ **Formulario de Cotización** - Envía emails a skybudgetfly@gmail.com vía EmailJS
✅ **Búsqueda de Aeropuertos** - Estilo Google Flights con 500+ aeropuertos integrados (funciona sin backend)
✅ **Responsive Design** - Funciona en móviles, tablets y desktop
✅ **SEO Optimizado** - Meta tags, Open Graph, Schema.org
✅ **Páginas de Términos y Privacidad** - Completamente traducidas

## Variables de Entorno Requeridas
Tu hosting debe tener estas variables de entorno configuradas:

```env
VITE_EMAILJS_PUBLIC_KEY=tu_clave_publica_emailjs
VITE_EMAILJS_SERVICE_ID=tu_service_id_emailjs  
VITE_EMAILJS_TEMPLATE_ID=tu_template_id_emailjs
```

## Instrucciones de Subida
1. **Extrae el archivo:** `tar -xzf skybudget-website-with-static-airports.tar.gz`
2. **Sube todo el contenido** a tu carpeta `public/` del servidor
3. **Configura las variables de entorno** en tu panel de hosting
4. **Verifica que funcione** accediendo a tu dominio

**NOTA:** La búsqueda de aeropuertos funciona automáticamente sin necesidad de base de datos.

## Funcionalidades del Sitio
- **Formulario de Cotización:** Envía automáticamente a skybudgetfly@gmail.com
- **Selector de Idioma:** Cambia entre Inglés y Español
- **Navegación Inteligente:** Funciona desde cualquier página
- **Búsqueda de Aeropuertos:** Predictiva y rápida
- **Mensaje de Éxito:** Menciona descuento del 40%

## Soporte Técnico
- Email: skybudgetfly@gmail.com
- Todas las librerías están incluidas y compiladas
- No requiere instalación adicional de dependencias

---
**Compilado:** Agosto 11, 2025
**Versión:** Final con navegación completa y sistema de emails