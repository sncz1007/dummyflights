# SkyBudgetFly.com - Versión que SÍ Funciona

## Archivo Correcto para Descargar
**`skybudgetfly-working-version.tar.gz`** - Esta es la versión que funciona en Replit

## IMPORTANTE: Configuración en el Servidor
Para que EmailJS funcione en tu servidor, necesitas configurar las 3 variables de entorno:

```
VITE_EMAILJS_PUBLIC_KEY=vJ5MUQsmMZgcCzqj7
VITE_EMAILJS_SERVICE_ID=service_ew4v4lb
VITE_EMAILJS_TEMPLATE_ID=template_vzm2hkf
```

## Instrucciones para skybudgetfly.com

### Paso 1: Subir Archivos
1. Descarga `skybudgetfly-working-version.tar.gz`
2. Extrae: `tar -xzf skybudgetfly-working-version.tar.gz`
3. Sube TODO el contenido a la carpeta `public/` de tu servidor

### Paso 2: Configurar Variables de Entorno
**En tu panel de hosting/servidor, agrega estas 3 variables:**
- `VITE_EMAILJS_PUBLIC_KEY` = `vJ5MUQsmMZgcCzqj7`
- `VITE_EMAILJS_SERVICE_ID` = `service_ew4v4lb`
- `VITE_EMAILJS_TEMPLATE_ID` = `template_vzm2hkf`

### Paso 3: Verificar
1. Ir a skybudgetfly.com
2. Probar formulario de cotización
3. Verificar que llega email a skybudgetfly@gmail.com

## Funcionalidades Incluidas
✅ Formulario EmailJS (requiere configuración en servidor)
✅ Búsqueda de aeropuertos (500+ aeropuertos integrados)
✅ Navegación completa entre páginas
✅ Sistema bilingüe (inglés/español)
✅ Responsive design
✅ SEO optimizado

**NOTA:** Esta es exactamente la misma versión que funciona perfectamente aquí en Replit.

Fecha: Agosto 11, 2025